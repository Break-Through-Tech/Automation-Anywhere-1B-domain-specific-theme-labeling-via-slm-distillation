#!/usr/bin/env python3
"""
remeasure_latency.py -- NO retraining. Loads a finished run's saved LoRA adapter and re-measures per-label latency for
  baseline            (same base model, adapter DISABLED)
  finetuned           (adapter ENABLED, unmerged  - what your pipeline served)
  finetuned_merged    (adapter merged into 16-bit weights - the realistic production setup; skip with --no-merged)
  teacher             (optional --teacher: live Haiku 4.5 call per item, includes network, sequential)
on the exact prompts in the run's test.jsonl, one item at a time (batch size 1), greedy decoding, max 60 new tokens.

Timing = tokenization + host->GPU transfer + generate + decode, with cuda.synchronize at both ends; model load, warmup
(untimed, --warmup items) and disk writes are excluded. Items are shuffled with a fixed seed to avoid order effects.

VALIDITY CHECK: each regenerated label is compared with the label stored in the run's *_predictions.jsonl (the one your
judge scored). `match_stored` shows whether the speed numbers describe the same outputs. Judge scores are keyed to the
STORED label, so build_17col.py keeps the stored label and only swaps in latency.

  python remeasure_latency.py --run-dir /content/drive/MyDrive/slm-distillation/runs/<exp>/<name>/outputs/<run_id> \
        --out /content/drive/MyDrive/slm-distillation/consolidated/latency/<name>.csv [--teacher] [--dtype bf16|fp16]

Output CSV columns: run, role, cluster_id, prompt_id, latency_s, output, stored_output, match_stored
Needs: torch, transformers, peft (Colab GPU). --teacher also needs ANTHROPIC_API_KEY. Writes nothing inside the run dir.
"""
import argparse, csv, glob, json, os, random, re, statistics as st, sys, time
from pathlib import Path


def read_jsonl(p):
    out = []
    for line in open(p, encoding='utf-8'):
        line = line.strip()
        if line:
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return out


def run_key(run_dir):
    parts = Path(run_dir).resolve().parts
    return '/'.join(parts[parts.index('runs') + 1:]) if 'runs' in parts else str(run_dir)


def load_items(run_dir):
    p = Path(run_dir) / 'test.jsonl'
    if not p.exists():
        sys.exit(f'no test.jsonl in {run_dir}')
    items, seen = [], set()
    for r in read_jsonl(p):
        k = (str(r['cluster_id']), str(r['prompt_id']))
        if k in seen or int(r.get('variant_id', 0) or 0) != 0:
            continue
        seen.add(k)
        items.append({'cluster_id': k[0], 'prompt_id': k[1], 'prompt': r['prompt']})
    return items


def stored_outputs(run_dir):
    """labels your pipeline generated (and the judge scored), per role"""
    out = {'baseline': {}, 'finetuned': {}, 'teacher': {}}
    for d in [Path(run_dir) / 'evaluation'] + sorted(Path(run_dir).glob('evaluation*')):
        for role in out:
            p = d / f'{role}_predictions.jsonl'
            if p.exists() and not out[role]:
                for r in read_jsonl(p):
                    out[role][(str(r['cluster_id']), str(r['prompt_id']))] = r.get('generated_label', '').strip()
    return out


def parse_messages(text):
    m = re.findall(r'<\|start_header_id\|>(system|user)<\|end_header_id\|>\n\n(.*?)<\|eot_id\|>', text, re.S)
    if not m:
        m = re.findall(r'<\|im_start\|>(system|user)\n(.*?)<\|im_end\|>', text, re.S)
    msgs = [{'role': r, 'content': re.sub(r'^Cutting Knowledge Date:.*?\nToday Date:.*?\n\n', '', c, flags=re.S).strip()} for r, c in m]
    return msgs


# ------------------------------------------------------------------------------- GPU side (lazy imports)
def resolve_base_id(adapter, override=None):
    """adapter_config.json can hold base_model_name_or_path = null (Unsloth). Fall back: override -> README front-matter -> adapter path text -> Llama-3.2-3B default."""
    adapter = Path(adapter)
    if override:
        return override
    try:
        v = json.load(open(adapter / 'adapter_config.json')).get('base_model_name_or_path')
        if v and v != 'None':
            return v
    except Exception:
        pass
    try:
        m = re.search(r'^base_model:\s*(\S+)', (adapter / 'README.md').read_text(errors='ignore'), re.M)
        if m and m.group(1).lower() not in ('null', 'none'):
            return m.group(1).strip('"\'')
    except Exception:
        pass
    txt = str(adapter.resolve()).lower()
    for key, rid in (('llama-3.2-3b', 'meta-llama/Llama-3.2-3B-Instruct'), ('smollm2-1.7b', 'HuggingFaceTB/SmolLM2-1.7B-Instruct'),
                     ('smollm2-360m', 'HuggingFaceTB/SmolLM2-360M-Instruct')):
        if key in txt:
            print(f'[base] adapter_config has no base model; inferred {rid} from the run path')
            return rid
    sys.exit('cannot tell the base model: pass --base-model meta-llama/Llama-3.2-3B-Instruct')


def fix_adapter_keys(adapter):
    """some adapters were saved from a double-wrapped PeftModel: keys start 'base_model.model.base_model.model.'.
    PEFT then loads NOTHING (silently). Write a corrected copy to local disk and return its path (original untouched)."""
    import shutil
    from safetensors import safe_open
    from safetensors.torch import save_file
    adapter = Path(adapter)
    f = adapter / 'adapter_model.safetensors'
    if not f.exists():
        return adapter
    with safe_open(str(f), framework='pt') as sf:
        keys = list(sf.keys())
        if not keys or not all(k.startswith('base_model.model.base_model.model.') for k in keys):
            return adapter
        tensors = {k[len('base_model.model.'):]: sf.get_tensor(k) for k in keys}
    dst = Path('/content/_adapter_fixed') if Path('/content').exists() else Path('/tmp/_adapter_fixed')
    shutil.rmtree(dst, ignore_errors=True)
    dst.mkdir(parents=True)
    save_file(tensors, str(dst / 'adapter_model.safetensors'), metadata={'format': 'pt'})
    shutil.copy(adapter / 'adapter_config.json', dst / 'adapter_config.json')
    print(f'[adapter] fixed doubled key prefix on {len(tensors)} tensors -> {dst}')
    return dst


def load_models(adapter, dtype_name, load_4bit, base_override=None):
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from peft import PeftModel
    base_id = resolve_base_id(adapter, base_override)
    dtype = {'bf16': torch.bfloat16, 'fp16': torch.float16}[dtype_name]
    tok = AutoTokenizer.from_pretrained(base_id)
    kw = dict(torch_dtype=dtype, device_map={'': 0})
    if load_4bit:
        from transformers import BitsAndBytesConfig
        kw['quantization_config'] = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type='nf4', bnb_4bit_compute_dtype=dtype)
    base = AutoModelForCausalLM.from_pretrained(base_id, **kw)
    model = PeftModel.from_pretrained(base, str(fix_adapter_keys(adapter)))
    model.eval()
    # GUARD: if the checkpoint keys did not match, LoRA stays at init (lora_B == 0) and 'fine-tuned' == baseline
    bsum, nb = 0.0, 0
    for n_, p_ in model.named_parameters():
        if 'lora_B' in n_:
            bsum += float(p_.detach().abs().float().sum()); nb += 1
    print(f'[adapter] {nb} lora_B tensors, sum|B| = {bsum:.4f}')
    if nb == 0 or bsum == 0.0:
        sys.exit('ABORT: LoRA weights were NOT loaded (all lora_B are zero) -> fine-tuned would equal baseline. '
                 'Run the adapter-key diagnostic; do not generate.')
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    return model, tok, base_id


def eos_ids(tok):
    ids = {tok.eos_token_id}
    for t in ('<|eot_id|>', '<|im_end|>', '<end_of_turn>'):
        i = tok.convert_tokens_to_ids(t)
        if isinstance(i, int) and i >= 0 and i != tok.unk_token_id:
            ids.add(i)
    return [i for i in ids if i is not None]


def generate_one(model, tok, prompt, max_new, eos):
    """returns (label, seconds)"""
    import torch
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    enc = tok(prompt, return_tensors='pt', add_special_tokens=False).to(model.device)   # prompt already holds BOS/template
    with torch.inference_mode():
        out = model.generate(**enc, max_new_tokens=max_new, do_sample=False, eos_token_id=eos,
                             pad_token_id=tok.pad_token_id, use_cache=True)
    text = tok.decode(out[0, enc['input_ids'].shape[1]:], skip_special_tokens=True)
    torch.cuda.synchronize()
    return text.strip(), time.perf_counter() - t0


def teacher_one(msgs, key):
    import requests
    system = next((m['content'] for m in msgs if m['role'] == 'system'), '')
    user = [m for m in msgs if m['role'] == 'user']
    body = {'model': 'claude-haiku-4-5', 'temperature': 0.3, 'max_tokens': 60, 'system': system, 'messages': user}
    for attempt in range(5):
        t0 = time.perf_counter()
        r = requests.post('https://api.anthropic.com/v1/messages', json=body, timeout=90,
                          headers={'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json'})
        dt = time.perf_counter() - t0
        if r.status_code == 200:   # only successful requests are timed (retries excluded)
            txt = ''.join(c.get('text', '') for c in r.json().get('content', []) if c.get('type') == 'text')
            return txt.strip(), dt
        time.sleep(min(20, 2 ** attempt))
    raise RuntimeError('teacher call failed after retries')


# ------------------------------------------------------------------------------- measuring
def measure(role, items, fn, warmup, rows, runk, stored):
    """fn(prompt) -> (label, seconds). Warmup items are run first and discarded."""
    for it in items[:warmup]:
        fn(it)
    for n, it in enumerate(items, 1):
        label, dt = fn(it)
        k = (it['cluster_id'], it['prompt_id'])
        ref = stored.get(role if role != 'finetuned_merged' else 'finetuned', {}).get(k)
        rows.append({'run': runk, 'role': role, 'cluster_id': k[0], 'prompt_id': k[1], 'latency_s': dt, 'output': label,
                     'stored_output': ref if ref is not None else '',
                     'match_stored': ('' if ref is None else str(label == ref))})
        if n % 50 == 0:
            print(f'  {role}: {n}/{len(items)}', flush=True)


def summarize(rows):
    print('\nrole               n    mean_s  median   p95    labels/min  match_stored')
    for role in ('baseline', 'finetuned', 'finetuned_merged', 'teacher'):
        rr = [r for r in rows if r['role'] == role]
        if not rr:
            continue
        v = sorted(r['latency_s'] for r in rr)
        p95 = v[min(len(v) - 1, int(round(0.95 * (len(v) - 1))))]
        mt = [r['match_stored'] for r in rr if r['match_stored'] != '']
        ms = f"{sum(x == 'True' for x in mt)}/{len(mt)}" if mt else 'n/a'
        print(f'{role:18s} {len(v):4d} {st.mean(v):7.3f} {st.median(v):7.3f} {p95:6.3f} {60 / st.mean(v):10.1f}   {ms}')
    print('\nmatch_stored < 100% => regenerated labels differ from the labels your judge scored (different dtype/quantization/'
          'decoding than the original run). Latency is still valid for THIS setup; quality scores belong to the stored labels.')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--run-dir', required=True, help='.../outputs/<timestamp>_<model>_epN (contains models/lora_adapter and test.jsonl)')
    ap.add_argument('--out', required=True)
    ap.add_argument('--dtype', default='bf16', choices=['bf16', 'fp16'])
    ap.add_argument('--load-4bit', action='store_true', help='only if the run was trained/served 4-bit (QLoRA)')
    ap.add_argument('--no-merged', action='store_true')
    ap.add_argument('--base-model', default=None)
    ap.add_argument('--teacher', action='store_true')
    ap.add_argument('--max-new-tokens', type=int, default=60)
    ap.add_argument('--warmup', type=int, default=3)
    ap.add_argument('--limit', type=int, default=0, help='debug: only first N items')
    ap.add_argument('--seed', type=int, default=20261120)
    a = ap.parse_args()

    run_dir = Path(a.run_dir)
    adapters = glob.glob(str(run_dir / 'models' / 'lora_adapter')) or glob.glob(str(run_dir / '**' / 'adapter_config.json'), recursive=True)
    if not adapters:
        sys.exit(f'no adapter under {run_dir}')
    adapter = Path(adapters[0]).parent if adapters[0].endswith('adapter_config.json') else Path(adapters[0])
    items = load_items(run_dir)
    random.Random(a.seed).shuffle(items)
    if a.limit:
        items = items[:a.limit]
    stored = stored_outputs(run_dir)
    runk = run_key(run_dir)
    print(f'{len(items)} test items | adapter {adapter} | stored labels: ' + ', '.join(f'{k}={len(v)}' for k, v in stored.items()))

    import torch
    print('GPU:', torch.cuda.get_device_name(0), '| torch', torch.__version__)
    model, tok, base_id = load_models(adapter, a.dtype, a.load_4bit, getattr(a, 'base_model', None))
    eos = eos_ids(tok)
    rows = []
    gen = lambda it: generate_one(model, tok, it['prompt'], a.max_new_tokens, eos)

    with model.disable_adapter():
        measure('baseline', items, gen, a.warmup, rows, runk, stored)
    measure('finetuned', items, gen, a.warmup, rows, runk, stored)
    if not a.no_merged:
        if a.load_4bit:
            print('skipping merged measurement: merging into 4-bit weights destroys the fine-tune (merge only in 16-bit)')
        else:
            model = model.merge_and_unload()
            model.eval()
            measure('finetuned_merged', items, gen, a.warmup, rows, runk, stored)
    if a.teacher:
        key = os.environ.get('ANTHROPIC_API_KEY')
        if not key:
            sys.exit('--teacher needs ANTHROPIC_API_KEY')
        tfn = lambda it: teacher_one(parse_messages(it['prompt']), key)
        measure('teacher', items, tfn, 0, rows, runk, stored)

    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    with open(a.out, 'w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['run', 'role', 'cluster_id', 'prompt_id', 'latency_s', 'output', 'stored_output', 'match_stored'])
        w.writeheader()
        w.writerows(rows)
    print(f'\nbase model {base_id} | dtype {a.dtype} | 4bit {a.load_4bit} | saved {a.out}')
    summarize(rows)


if __name__ == '__main__':
    main()
