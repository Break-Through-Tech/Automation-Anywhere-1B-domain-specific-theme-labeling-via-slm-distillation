#!/usr/bin/env python3
"""
validate_17col.py CSV [CSV ...]  -- checks a generated file against the template rules and prints a per-model summary.
Checks: exact 17 headers/order; Batch/Batch Size rule; scores 1-5; cosine/ROUGE/BERT in [0,1]; Composite == mean of the
three; Actual Prompt + Input are valid JSON; no duplicate (model,prompt id,input,output); blanks counted per column.
Exit code 1 if any hard check fails.
"""
import csv, json, statistics as st, sys
from collections import defaultdict
csv.field_size_limit(10**9)
COLS = ['Name of Model', 'Model Owner', 'Prompt ID', 'Actual Prompt', 'Input to the Model', 'Output of the Model', 'Latency',
        'Batch', 'Batch Size', 'Faithfulness', 'Relevance', 'Specificity', 'Composite', 'Cosine Score', 'ROUGE', 'BertScore',
        'Estimated/Approx Cost']


def f(x):
    try:
        return float(x)
    except Exception:
        return None


def pct(v, q):
    v = sorted(v)
    return v[min(len(v) - 1, int(round(q * (len(v) - 1))))] if v else None


def run(path):
    bad = []
    rows = list(csv.DictReader(open(path, encoding='utf-8', newline='')))
    hdr = list(rows[0].keys()) if rows else []
    if hdr != COLS:
        bad.append(f'header differs: {hdr}')
    seen, blanks, dups = set(), defaultdict(int), []
    g = defaultdict(list)
    for i, r in enumerate(rows, start=2):
        for c in COLS:
            if r.get(c, '') == '':
                blanks[c] += 1
        k = (r['Name of Model'], r['Prompt ID'], r['Batch Size'], r['Input to the Model'], r['Output of the Model'])
        if k in seen:
            dups.append(i)
        seen.add(k)
        for c in ('Actual Prompt', 'Input to the Model'):
            try:
                json.loads(r[c])
            except Exception:
                bad.append(f'line {i}: {c} is not valid JSON')
        bs = f(r['Batch Size'])
        if bs is None or (r['Batch'] == 'YES') != (bs > 1):
            bad.append(f'line {i}: Batch/Batch Size inconsistent')
        s = [f(r[c]) for c in ('Faithfulness', 'Relevance', 'Specificity')]
        for v in s:
            if v is not None and not 1 <= v <= 5:
                bad.append(f'line {i}: judge score out of 1-5')
        if None not in s and f(r['Composite']) is not None and abs(sum(s) / 3 - f(r['Composite'])) > 1e-6:
            bad.append(f'line {i}: Composite != mean')
        for c in ('Cosine Score', 'ROUGE', 'BertScore'):
            v = f(r[c])
            if v is not None and not -1e-6 <= v <= 1 + 1e-4:
                bad.append(f'line {i}: {c}={v} out of [0,1]')
        g[r['Name of Model']].append(r)
    print(f'\n{path}: {len(rows)} rows, {len(g)} model configs')
    print('blank cells per column:', {c: n for c, n in blanks.items()} or 'none')
    print(f"{'model':92s} {'n':>4s} {'faith':>5s} {'rel*':>5s} {'spec':>5s} {'comp':>5s} {'cos':>5s} {'rgL':>5s} {'bert':>5s} {'lat':>6s} {'p95':>6s} {'$/1k':>7s}")
    m = lambda rs, c: (lambda v: sum(v) / len(v) if v else None)([f(r[c]) for r in rs if f(r[c]) is not None])
    p = lambda x, n=3: '' if x is None else f'{x:.{n}f}'
    for name, rs in g.items():
        lat = [f(r['Latency']) for r in rs if f(r['Latency']) is not None]
        cost = m(rs, 'Estimated/Approx Cost')
        print(f"{name[:92]:92s} {len(rs):>4d} {p(m(rs,'Faithfulness')):>5s} {p(m(rs,'Relevance')):>5s} {p(m(rs,'Specificity')):>5s} "
              f"{p(m(rs,'Composite')):>5s} {p(m(rs,'Cosine Score')):>5s} {p(m(rs,'ROUGE')):>5s} {p(m(rs,'BertScore')):>5s} "
              f"{p(sum(lat)/len(lat) if lat else None):>6s} {p(pct(lat,.95)):>6s} {p(cost*1000 if cost is not None else None,4):>7s}")
    print('* rel = Relevance column (reference mode: equivalence; reference_free: COHERENCE in this pipeline - see PROVENANCE)')
    if dups:
        print(f'WARNING: {len(dups)} duplicate rows (same model/prompt/batch size/input/output), e.g. lines {dups[:5]} - fine if partial batches, otherwise a double-append')
    if bad:
        print(f'\nFAILED {len(bad)} checks (first 20):')
        for b in bad[:20]:
            print('  -', b)
    else:
        print('\nall hard checks passed')
    return not bad


if __name__ == '__main__':
    ok = all([run(p) for p in sys.argv[1:]]) if len(sys.argv) > 1 else sys.exit('usage: validate_17col.py CSV [CSV...]')
    sys.exit(0 if ok else 1)
