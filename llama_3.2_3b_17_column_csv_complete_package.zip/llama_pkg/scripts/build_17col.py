#!/usr/bin/env python3
"""
build_17col.py  --  consolidate YOUR finetune runs into the teammates' 17-column CSV format.

Reads, for every evaluation folder it finds under <drive-root>/runs:
    {teacher,baseline,finetuned}_predictions.jsonl   (optional, only used as fallback)
    llm_{teacher,baseline,finetuned}.csv             (judge scores: faithfulness/specificity/equivalence|coherence)
    nonllm_{...}.csv                                 (cosine / ROUGE-L / BERTScore, *_same = same-prompt teacher ref)
    latency_{...}.csv  (teacher: latency_teacher.csv or teacher_latency_records.csv)
    business_eval.csv                                (teacher $/call)
    test.jsonl / val.jsonl / train.jsonl             (exact prompt + the tickets the model saw)

Judge mode is auto-detected per file:  "coherence" in llm_metrics -> reference_free,
                                       "equivalence"             -> reference.
Output (exactly 17 columns, template order), one CSV per judge mode:
    <out>/slm_<tag>_reference_free_17col.csv
    <out>/slm_<tag>_reference_17col.csv
    <out>/slm_<tag>_PROVENANCE.csv   (same row order: run path, judge mode, 3rd judge dimension, sources)

Column 'Relevance' <- reference mode: 'equivalence' ; reference_free mode: 'coherence'
(your pipeline's reference-free rubric scores coherence, NOT relevance - the shared template scored
 relevance. PROVENANCE says which was used; do not mix them silently when comparing to teammates.)

Usage (Colab):
    !python build_17col.py --drive-root /content/drive/MyDrive/slm-distillation --out /content/drive/MyDrive/slm-distillation/consolidated \
        --owner "YOUR NAME" --include llama_3.2_3b smollm
Add --dry-run to only list what it finds. Read-only on your runs; never deletes or overwrites run files.
"""
import argparse, csv, json, re, sys
from collections import defaultdict
from pathlib import Path

COLUMNS = ['Name of Model', 'Model Owner', 'Prompt ID', 'Actual Prompt', 'Input to the Model',
           'Output of the Model', 'Latency', 'Batch', 'Batch Size', 'Faithfulness', 'Relevance',
           'Specificity', 'Composite', 'Cosine Score', 'ROUGE', 'BertScore', 'Estimated/Approx Cost']
ROLES = ['baseline', 'finetuned', 'teacher']
csv.field_size_limit(10 ** 9)


# ----------------------------------------------------------------------------- helpers
def read_csv(p):
    with open(p, encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def read_jsonl(p):
    out = []
    with open(p, encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    out.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
    return out


def key(r):
    return (str(r['cluster_id']).strip(), str(r['prompt_id']).strip())


def fnum(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def find_key(obj, name):
    """first value of `name` anywhere in nested dict/list, else None"""
    if isinstance(obj, dict):
        if name in obj:
            return obj[name]
        for v in obj.values():
            r = find_key(v, name)
            if r is not None:
                return r
    elif isinstance(obj, list):
        for v in obj:
            r = find_key(v, name)
            if r is not None:
                return r
    return None


def parse_prompt(text):
    """raw chat-template string -> (messages list, [tickets]). Handles Llama-3 and ChatML templates."""
    msgs = []
    m = re.findall(r'<\|start_header_id\|>(system|user|assistant)<\|end_header_id\|>\n\n(.*?)<\|eot_id\|>', text, re.S)
    if not m:
        m = re.findall(r'<\|im_start\|>(system|user|assistant)\n(.*?)<\|im_end\|>', text, re.S)
    for role, content in m:
        content = re.sub(r'^Cutting Knowledge Date:.*?\nToday Date:.*?\n\n', '', content, flags=re.S)
        if role != 'assistant':
            msgs.append({'role': role, 'content': content.strip()})
    if not msgs:
        msgs = [{'role': 'user', 'content': text.strip()}]
    user = next((x['content'] for x in msgs if x['role'] == 'user'), text)
    tickets = re.findall(r'^Ticket \d+:\s*(.*)$', user, re.M)
    return msgs, [t.strip() for t in tickets]


def model_id_from(folder_name, pred_rows):
    for r in pred_rows:
        if r.get('model') and '/' in str(r['model']):
            return str(r['model'])
    m = re.search(r'\d{8}_\d{4}_(.+?)_ep\d+', folder_name)
    n = m.group(1) if m else folder_name
    if n.lower().startswith('llama'):
        return 'meta-llama/' + n
    if n.lower().startswith('smollm'):
        return 'HuggingFaceTB/' + n
    return n


# ----------------------------------------------------------------------------- discovery
def discover(runs_dir, include, exclude):
    dirs = set()
    for pat in ('llm_finetuned.csv', 'llm_baseline.csv', 'llm_teacher.csv'):
        for p in runs_dir.rglob(pat):
            dirs.add(p.parent)
    out = []
    for d in sorted(dirs):
        s = str(d)
        if include and not any(i in s for i in include):
            continue
        if exclude and any(e in s for e in exclude):
            continue
        out.append(d)
    return out


def run_dir_of(eval_dir):
    return eval_dir.parent if eval_dir.name.startswith('evaluation') else eval_dir


class Finder:
    """look for a file in eval_dir first, then in sibling evaluation* folders / run dir"""
    def __init__(self, eval_dir):
        self.eval_dir = eval_dir
        self.run_dir = run_dir_of(eval_dir)
        sib = [p for p in sorted(self.run_dir.glob('evaluation*')) if p.is_dir() and p != eval_dir]
        self.order = [eval_dir] + sib + ([self.run_dir] if self.run_dir != eval_dir else [])

    def __call__(self, *names):
        for d in self.order:
            for n in names:
                p = d / n
                if p.exists():
                    return p
        return None


def load_prompt_index(run_dir):
    idx = {}
    for fn in ('test.jsonl', 'val.jsonl', 'train.jsonl'):
        p = run_dir / fn
        if not p.exists():
            continue
        for r in read_jsonl(p):
            k = (str(r.get('cluster_id')), str(r.get('prompt_id')))
            if k not in idx and 'prompt' in r:
                idx[k] = r['prompt']
        if fn == 'test.jsonl' and idx:
            pass
    return idx


def precision_of(run_dir):
    for fn in ('experiment_config.json', 'training_summary.json'):
        p = run_dir / fn
        if p.exists():
            try:
                v = find_key(json.load(open(p)), 'load_in_4bit')
            except Exception:
                v = None
            if v is True:
                return '4-bit NF4'
            if v is False:
                return 'bf16/fp16'
    return 'precision n/a'


def teacher_cost_per_call(finder, override):
    if override is not None:
        return override, 'cli'
    p = finder('business_eval.csv')
    if p:
        d = {r['metric']: fnum(r['value']) for r in read_csv(p) if 'metric' in r}
        c, n = d.get('teacher_llm_estimated_cost_usd'), d.get('label_gen_total_calls')
        if c is not None and n:
            return c / n, 'business_eval.csv (total/calls)'
    return 0.00013, 'fallback $0.00013/call (measured earlier)'



# ----------------------------------------------------------------------------- locating prompts / tickets
_SPECIAL_TAIL = re.compile(r'(<\|[^|>]+\|>|<end_of_turn>|</s>)+\s*$')
_DATA_CACHE = {}


def norm_label(t):
    return _SPECIAL_TAIL.sub('', (t or '').strip()).strip()


def data_test_index(path):
    """(cluster_id, prompt_id) -> (prompt, completion) from a data folder's test.jsonl (cached)"""
    if path not in _DATA_CACHE:
        idx = {}
        for r in read_jsonl(path):
            k = (str(r.get('cluster_id')), str(r.get('prompt_id')))
            if k not in idx and 'prompt' in r:
                idx[k] = (r['prompt'], norm_label(r.get('completion', '')))
        _DATA_CACHE[path] = idx
    return _DATA_CACHE[path]


def find_prompt_source(run_dir, ref_labels, data_root):
    """Pick the prompt file whose stored teacher labels match the run's reference labels (so the right dataset is used).
    Returns (idx{key->prompt}, description, match_fraction)."""
    cands = []
    for fn in ('test.jsonl', 'val.jsonl', 'train.jsonl'):
        if (run_dir / fn).exists():
            cands.append(run_dir / fn)
    if data_root.exists():
        cands += sorted(set(data_root.glob('*/test.jsonl')) | set(data_root.glob('*/*/test.jsonl')))
    best = (None, '', 0.0)
    for c in cands:
        idx = data_test_index(c)
        hit = sum(1 for k, ref in ref_labels.items() if k in idx and idx[k][1] == norm_label(ref))
        frac = hit / max(1, len(ref_labels))
        if frac > best[2]:
            best = ({k: v[0] for k, v in idx.items()}, str(c), frac)
    if best[0] is not None and best[2] >= 0.8:
        return best
    return {}, '', best[2]


def find_tickets_source(run_dir, ref_labels, data_root):
    """Fallback when no prompt file matches: tickets (ordered, top 10) from a labeled csv whose per-prompt teacher label
    columns match the stored reference labels. Returns (cluster->tickets, description, match_fraction)."""
    cands = [run_dir / 'labeled_data.csv'] if (run_dir / 'labeled_data.csv').exists() else []
    if data_root.exists():
        cands += sorted(set(data_root.glob('*/bitext_labeled.csv')))
    best = ({}, '', 0.0)
    for c in cands:
        try:
            rows = read_csv(c)
        except Exception:
            continue
        if not rows or 'ticket_details' not in rows[0]:
            continue
        pcols = {m.group(1): col for col in rows[0] if (m := re.search(r'cluster_name.*_(P\d)$', col))}
        lab = {}
        tk = {}
        for r in rows:
            cid = str(r['cluster_id'])
            tk.setdefault(cid, []).append((fnum(r.get('ticket_rank_in_cluster')) or 0, r['ticket_details']))
            for pid, col in pcols.items():
                lab.setdefault((cid, pid), norm_label(r[col]))
        hit = sum(1 for k, ref in ref_labels.items() if lab.get(k) == norm_label(ref))
        frac = hit / max(1, len(ref_labels))
        if frac > best[2]:
            best = ({c_: [t for _, t in sorted(v)][:10] for c_, v in tk.items()}, str(c), frac)
    if best[2] >= 0.8:
        return best
    return {}, '', best[2]

# ----------------------------------------------------------------------------- per-eval-dir build
def build_eval_dir(eval_dir, args, warn):
    finder = Finder(eval_dir)
    run_dir = finder.run_dir
    # reference labels of this run (stored teacher label per cluster/prompt) -> used to pick the right dataset files
    ref_labels = {}
    for role_ in ROLES:
        pp = eval_dir / f'llm_{role_}.csv'
        if pp.exists():
            for r_ in read_csv(pp):
                if r_.get('reference_label'):
                    ref_labels[key(r_)] = r_['reference_label']
    prompt_idx, prompt_desc, prompt_frac = find_prompt_source(run_dir, ref_labels, args.data_root)
    tickets_idx, tickets_desc, tickets_frac = ({}, '', 0.0)
    if not prompt_idx:
        tickets_idx, tickets_desc, tickets_frac = find_tickets_source(run_dir, ref_labels, args.data_root)
        warn(f'{run_dir.name}: no prompt file matched the stored labels (best {prompt_frac:.0%}); '
             + (f'tickets taken from {Path(tickets_desc).parent.name}/{Path(tickets_desc).name} ({tickets_frac:.0%} label match), Actual Prompt left empty'
                if tickets_idx else 'Input and Actual Prompt left EMPTY - cannot be re-judged'))
    prec = args.precision or precision_of(run_dir)
    t_cost, t_cost_src = teacher_cost_per_call(finder, args.teacher_cost_per_call)
    rel = eval_dir.relative_to(args.runs_dir)
    parts = [x for x in rel.parts if x != 'outputs']
    tag = '/'.join(parts)

    pred_any = []
    for r in ROLES:
        p = eval_dir / f'{r}_predictions.jsonl'
        if p.exists():
            pred_any += read_jsonl(p)[:3]
    mid_ft = model_id_from(run_dir.name, pred_any)

    rows_by_mode = defaultdict(list)
    for role in ROLES:
        llm_p = eval_dir / f'llm_{role}.csv'
        if not llm_p.exists():
            continue
        llm = {}
        for r in read_csv(llm_p):
            llm[key(r)] = r  # duplicates: keep last
        non_p = finder(f'nonllm_{role}.csv')
        non = {key(r): r for r in read_csv(non_p)} if non_p else {}
        lat_p = finder(f'latency_{role}.csv') if role != 'teacher' else finder('latency_teacher.csv', 'teacher_latency_records.csv')
        lat = {}
        if lat_p:
            for r in read_csv(lat_p):
                v = fnum(r.get('latency_s', r.get('elapsed_s')))
                lat[key(r)] = v
        runk = str(run_dir.relative_to(args.runs_dir)) if run_dir != args.runs_dir else str(run_dir)
        ov_role = args.finetuned_latency_role if role == 'finetuned' else role
        n_ov = 0
        for k in list(llm.keys()):
            ov = args.lat_override.get((runk, ov_role, k[0], k[1]))
            if ov is not None:
                lat[k] = ov
                n_ov += 1
        lat_src = ('re-measured: ' + ov_role) if n_ov else None
        n_mis = 0
        for k, r in sorted(llm.items(), key=lambda kv: (int(kv[0][0]) if kv[0][0].lstrip('-').isdigit() else 0, kv[0][1])):
            try:
                m = json.loads(r['llm_metrics'])
            except Exception:
                warn(f'{tag}: unparsable llm_metrics for {role} {k}')
                continue
            mode = 'reference_free' if 'coherence' in m else ('reference' if 'equivalence' in m else 'unknown')
            third_name = 'coherence' if 'coherence' in m else ('equivalence' if 'equivalence' in m else 'relevance')
            third = m.get('relevance', m.get('equivalence', m.get('coherence')))
            faith, spec = m.get('faithfulness'), m.get('specificity')
            note = ''
            if role == 'teacher' and mode == 'reference':
                faith = spec = third = None          # hard-coded 5/5/5 shortcut in reference mode -> not a measurement
                note = 'teacher judge scores blank: reference-mode shortcut (not a real rating)'
            # judge failure sentinel: scores must be 1-5; 0 (or anything outside) = failed parse, not a rating
            if any(v is not None and not (1 <= v <= 5) for v in (faith, spec, third)):
                warn(f'{tag}: judge failure (score outside 1-5: {faith}/{spec}/{third}) for {role} {k} -> scores blanked')
                faith = spec = third = None
                note = (note + '; ' if note else '') + 'judge returned out-of-range scores (failed call) -> blank'
            comp = None
            if None not in (faith, spec, third):
                comp = (faith + spec + third) / 3.0
                jc = fnum(m.get('composite'))
                if jc is not None and abs(jc - comp) > 1e-6:
                    warn(f'{tag}: composite mismatch {role} {k}: judge {jc} vs mean {comp}')
            label = r.get('generated_label', '')
            # similarity (vs same-cluster same-prompt teacher label)
            cos = rouge = bert = None
            sim_src = 'pipeline_stored(_same)'
            if role == 'teacher':
                cos = rouge = bert = 1.0
                sim_src = 'identity (teacher vs itself)'
            elif k in non:
                nr = non[k]
                if nr.get('generated_label', label) != label:
                    n_mis += 1
                else:
                    try:
                        nm = json.loads(nr['nonllm_metrics'])
                        cos, rouge, bert = nm.get('cosine_sim_same'), nm.get('rouge_l_same'), nm.get('bertscore_f1_same')
                    except Exception:
                        pass
            latency = lat.get(k)
            if role == 'teacher':
                cost = t_cost
            else:
                cost = latency * args.rate / 3600.0 if latency is not None else None
            # prompt / tickets
            raw = prompt_idx.get(k)
            if raw:
                msgs, tickets = parse_prompt(raw)
                psrc = f'{Path(prompt_desc).parent.name}/{Path(prompt_desc).name} (label match {prompt_frac:.0%})'
            elif k[0] in tickets_idx:
                msgs, tickets = [], tickets_idx[k[0]]
                psrc = f'tickets only: {Path(tickets_desc).parent.name}/{Path(tickets_desc).name} (label match {tickets_frac:.0%}); prompt text not found'
            else:
                msgs, tickets, psrc = [], [], 'MISSING'
            mid = 'claude-haiku-4-5' if role == 'teacher' else mid_ft
            ft_lbl = 'fine-tuned, LoRA merged 16-bit' if (args.finetuned_latency_role == 'finetuned_merged' and n_ov) else 'fine-tuned, LoRA adapter'
            rl = {'baseline': 'baseline', 'finetuned': ft_lbl, 'teacher': 'teacher'}[role]
            name = f'{mid} ({rl})' if role == 'teacher' else f'{mid} ({rl}, {prec}) [{tag}]'
            rec = {
                'Name of Model': name, 'Model Owner': args.owner, 'Prompt ID': k[1],
                'Actual Prompt': json.dumps(msgs, ensure_ascii=False),
                'Input to the Model': json.dumps(tickets, ensure_ascii=False),
                'Output of the Model': label,
                'Latency': latency, 'Batch': 'NO', 'Batch Size': 1,
                'Faithfulness': faith, 'Relevance': third, 'Specificity': spec, 'Composite': comp,
                'Cosine Score': cos, 'ROUGE': rouge, 'BertScore': bert, 'Estimated/Approx Cost': cost,
            }
            prov = {'run': tag, 'cluster_id': k[0], 'role': role, 'judge_mode': mode, 'relevance_source': third_name,
                    'reference_label': r.get('reference_label', ''), 'similarity_source': sim_src,
                    'prompt_source': psrc, 'latency_file': (lat_src if (lat_src and k in lat and args.lat_override.get((runk, ov_role, k[0], k[1])) is not None) else (str(lat_p) if lat_p else 'MISSING')),
                    'nonllm_file': str(non_p) if non_p else 'MISSING',
                    'cost_basis': ('teacher ' + t_cost_src) if role == 'teacher' else f'latency x ${args.rate}/hr / 3600',
                    'note': note}
            rows_by_mode[mode].append((rec, prov))
        if n_mis:
            warn(f'{tag}: {n_mis} {role} rows had nonllm metrics for a DIFFERENT label (left blank)')
        if not lat_p and not n_ov:
            warn(f'{tag}: no latency file for {role}')
        if not non_p and role != 'teacher':
            warn(f'{tag}: no nonllm file for {role} -> Cosine/ROUGE/BertScore blank (use --recompute-sim)')
    return rows_by_mode


# ----------------------------------------------------------------------------- optional recompute of similarity
def recompute_similarity(items, warn):
    """Template-exact metrics: all-mpnet-base-v2 cosine, ROUGE-L F1 (stem), BERTScore F1 roberta-large L17, idf=False,
    no baseline rescale, vs same-cluster same-prompt teacher label (= reference_label). Needs GPU/net in Colab."""
    from sentence_transformers import SentenceTransformer
    from rouge_score import rouge_scorer
    from bert_score import BERTScorer
    MPNET, MPNET_REV = 'sentence-transformers/all-mpnet-base-v2', 'e8c3b32edf5434bc2275fc9bab85f82640a19130'

    def _clean_retry(make, repo_id, revision=None):
        """a truncated/corrupt cached download raises e.g. SafetensorError('header too large'): wipe it and re-fetch once"""
        try:
            return make(repo_id)
        except Exception as e:
            print(f'[metrics] loading {repo_id} failed ({type(e).__name__}: {str(e)[:90]}) -> re-downloading cleanly')
            import os, shutil, glob
            from huggingface_hub import snapshot_download
            hub = os.environ.get('HF_HUB_CACHE') or os.path.join(os.environ.get('HF_HOME', os.path.expanduser('~/.cache/huggingface')), 'hub')
            for d in glob.glob(os.path.join(hub, 'models--' + repo_id.replace('/', '--'))):
                shutil.rmtree(d, ignore_errors=True)
            path = snapshot_download(repo_id, revision=revision, force_download=True)
            return make(path)

    st = _clean_retry(lambda n: SentenceTransformer(n, revision=MPNET_REV) if n == MPNET else SentenceTransformer(n), MPNET, MPNET_REV)
    rs = rouge_scorer.RougeScorer(['rougeL'], use_stemmer=True)
    bs = _clean_retry(lambda n: BERTScorer(model_type=n if n == 'roberta-large' else 'roberta-large', num_layers=17, idf=False,
                                          rescale_with_baseline=False, use_fast_tokenizer=True), 'FacebookAI/roberta-large')
    todo = [(rec, prov) for rec, prov in items if prov['role'] != 'teacher' and prov['reference_label']]
    cands = [r['Output of the Model'] for r, _ in todo]
    refs = [p['reference_label'] for _, p in todo]
    if not todo:
        return
    ec = st.encode(cands, normalize_embeddings=True, batch_size=64)
    er = st.encode(refs, normalize_embeddings=True, batch_size=64)
    _, _, f1 = bs.score(cands, refs)
    for i, (rec, prov) in enumerate(todo):
        rec['Cosine Score'] = float((ec[i] * er[i]).sum())
        rec['ROUGE'] = rs.score(refs[i], cands[i])['rougeL'].fmeasure
        rec['BertScore'] = float(f1[i])
        prov['similarity_source'] = 'recomputed(mpnet, rougeL-stem, bertscore roberta-large L17)'


# ----------------------------------------------------------------------------- main
def fmt(v):
    if v is None:
        return ''
    if isinstance(v, float):
        return repr(v)
    return str(v)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--drive-root', default='/content/drive/MyDrive/slm-distillation')
    ap.add_argument('--out', default=None)
    ap.add_argument('--data-root', default=None, help='default <drive-root>/data (where test.jsonl / bitext_labeled.csv live)')
    ap.add_argument('--owner', default='vd35')
    ap.add_argument('--rate', type=float, default=0.526, help='$/hr VM+T4, historical VM+T4 rate')
    ap.add_argument('--teacher-cost-per-call', type=float, default=None)
    ap.add_argument('--include', nargs='*', default=[], help='substring filters on eval-dir path (any match)')
    ap.add_argument('--exclude', nargs='*', default=['_cache', '/checkpoints'])
    ap.add_argument('--tag', default='all')
    ap.add_argument('--precision', default=None, help="override the precision label in model names, e.g. 'bf16' or '4-bit NF4' (applies to ALL runs it processes; combine with --include)")
    ap.add_argument('--latency-override', nargs='*', default=[], help='CSV(s) from remeasure_latency.py; replaces Latency (and student cost) for matching run/role/cluster/prompt. Labels stay the stored, judged ones.')
    ap.add_argument('--finetuned-latency-role', default='finetuned', choices=['finetuned', 'finetuned_merged'],
                    help="which re-measured fine-tuned latency to use: 'finetuned' (unmerged adapter) or 'finetuned_merged' (merged 16-bit)")
    ap.add_argument('--recompute-sim', action='store_true')
    ap.add_argument('--dry-run', action='store_true')
    args = ap.parse_args()

    root = Path(args.drive_root)
    args.runs_dir = root / 'runs'
    args.data_root = Path(args.data_root) if args.data_root else root / 'data'
    out = Path(args.out) if args.out else root / 'consolidated'
    dirs = discover(args.runs_dir, args.include, args.exclude)
    print(f'found {len(dirs)} evaluation folders under {args.runs_dir}')
    if args.dry_run:
        for d in dirs:
            print('  ', d.relative_to(args.runs_dir))
        return

    warns = []
    def warn(m):
        warns.append(m)

    args.lat_override = {}
    for op in args.latency_override:
        for r in read_csv(op):
            v = fnum(r.get('latency_s'))
            if v is not None:
                args.lat_override[(r['run'], r['role'], str(r['cluster_id']), str(r['prompt_id']))] = v
    if args.latency_override:
        print(f'loaded {len(args.lat_override)} re-measured latencies from {len(args.latency_override)} file(s)')

    by_mode = defaultdict(list)
    for d in dirs:
        for mode, items in build_eval_dir(d, args, warn).items():
            by_mode[mode] += items
    if args.recompute_sim:
        for mode, items in by_mode.items():
            recompute_similarity(items, warn)

    out.mkdir(parents=True, exist_ok=True)
    for mode, items in by_mode.items():
        # teacher labels are shared by many runs -> keep ONE teacher row per (prompt, input, output); prefer one with latency
        items.sort(key=lambda x: x[0]['Latency'] is None)
        seen_t, kept = set(), []
        for rec, prov in items:
            if prov['role'] == 'teacher':
                k = (rec['Prompt ID'], rec['Input to the Model'], rec['Output of the Model'])
                if k in seen_t:
                    continue
                seen_t.add(k)
                prov['note'] = (prov['note'] + '; ' if prov['note'] else '') + 'teacher row shared by several runs (deduplicated)'
            kept.append((rec, prov))
        items[:] = kept
        items.sort(key=lambda x: (x[1]['run'], ROLES.index(x[1]['role']),
                                  int(x[1]['cluster_id']) if x[1]['cluster_id'].lstrip('-').isdigit() else 0, x[0]['Prompt ID']))
        fn = out / f'slm_{args.tag}_{mode}_17col.csv'
        with open(fn, 'w', encoding='utf-8', newline='') as f:
            w = csv.writer(f)
            w.writerow(COLUMNS)
            for rec, _ in items:
                w.writerow([fmt(rec[c]) for c in COLUMNS])
        pfn = out / f'slm_{args.tag}_{mode}_PROVENANCE.csv'
        pcols = list(items[0][1].keys())
        with open(pfn, 'w', encoding='utf-8', newline='') as f:
            w = csv.writer(f)
            w.writerow(['csv_line'] + pcols)
            for i, (_, p) in enumerate(items, start=2):
                w.writerow([i] + [p[c] for c in pcols])
        print(f'[{mode}] {len(items)} rows -> {fn}')
    if not by_mode:
        print('no rows produced - run with --dry-run to see what was found')
    if warns:
        print(f'\n{len(warns)} warnings (first 40):')
        for m in warns[:40]:
            print('  -', m)


if __name__ == '__main__':
    main()
