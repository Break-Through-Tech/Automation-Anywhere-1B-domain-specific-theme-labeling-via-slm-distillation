import pandas as pd, numpy as np, json, re, os
ROOT  = "/content/drive/MyDrive/slm-distillation"
CSV   = os.environ.get("CSV",   f"{ROOT}/consolidated/workload_confirm_v2/ancheng_format_full500.csv")
TRAIN = os.environ.get("TRAIN", f"{ROOT}/data/processed_raw_domain")      # folder the adapter trained on
THRESH = 4.0

l = pd.read_csv(CSV)
role = lambda n: 'teacher' if 'teacher' in n else 'baseline' if 'baseline' in n else 'finetuned'
l['role'] = l['Name of Model'].map(role)
l['key'] = l['Prompt ID'] + '||' + l['Input to the Model']
W = {r: x.set_index('key') for r, x in l.groupby('role')}
f, b, t = W['finetuned'], W['baseline'], W['teacher']
df = pd.DataFrame({'pid': f['Prompt ID'], 'tickets': f['Input to the Model'], 'ft': f['Output of the Model'],
                   'base': b['Output of the Model'], 'teacher': t['Output of the Model'],
                   'F': f['Faithfulness'], 'R': f['Relevance'], 'S': f['Specificity'], 'comp': f['Composite'],
                   'base_comp': b['Composite'], 'teacher_comp': t['Composite']})
df['cluster'] = df['tickets']                      # same tickets = same cluster
g = df.groupby('cluster', sort=False)
summ = g.agg(ft=('comp', 'mean'), base=('base_comp', 'mean'), teacher=('teacher_comp', 'mean'),
             S=('S', 'mean')).round(2)
summ['cid'] = [f"C{i:03d}" for i in range(len(summ))]
weak = summ[summ.ft < THRESH].sort_values('ft')
print(f"{len(weak)} weak clusters (fine-tuned composite < {THRESH}) of {len(summ)}; "
      f"mean ft {weak.ft.mean():.2f} vs teacher {weak.teacher.mean():.2f} vs baseline {weak.base.mean():.2f} on these\n")

def tickets_of(js, n=3):
    try: tk = json.loads(js)
    except Exception: return [js[:150]]
    return [str(x)[:160].replace('\n', ' ') for x in tk[:n]]

rows = []
for cl, s in weak.iterrows():
    d = df[df.cluster == cl]
    print(f"=== {s.cid}  ft {s.ft:.2f} | base {s.base:.2f} | teacher {s.teacher:.2f} | specificity {s.S:.2f}")
    for tk in tickets_of(cl): print("   ticket:", tk)
    for _, r in d.iterrows():
        print(f"   {r.pid} [{r.comp:.1f}] ft: {r.ft}   ||  teacher: {r.teacher}")
        rows.append(dict(cluster=s.cid, prompt=r.pid, composite=r.comp, F=r.F, R=r.R, S=r.S, finetuned=r.ft, teacher=r.teacher, baseline=r.base))
    print()
out = os.path.join(os.path.dirname(CSV), "weak_clusters.csv"); pd.DataFrame(rows).to_csv(out, index=False); print("saved", out)

# ---- training coverage of the weak theme
def read_texts(folder):
    texts = []
    for fn in ("train.jsonl", "val.jsonl"):
        p = os.path.join(folder, fn)
        if not os.path.exists(p): continue
        for line in open(p):
            try: r = json.loads(line)
            except Exception: continue
            c = r.get("completion")
            if c is None and isinstance(r.get("messages"), list): c = r["messages"][-1].get("content")
            if c: texts.append(str(c))
    return texts
tr = read_texts(TRAIN)
kw = re.compile(r"contact|agent|representative|live|human|chat|phone|speak|support", re.I)
tw = [x for x in tr if kw.search(x)]
wt = [x for x in df[df.cluster.isin(weak.index)].teacher.unique()]
print(f"\ntraining labels: {len(tr)} total, {len(tw)} mention contact/agent/chat/support words ({100*len(tw)/max(1,len(tr)):.0f}%)")
print(f"teacher labels on the weak clusters that use those words: {sum(bool(kw.search(x)) for x in wt)}/{len(wt)}")
print("sample training labels in that theme:"); [print("  -", x) for x in tw[:8]]
