#!/usr/bin/env python3
"""
build_train_v2.py -- build the training folder for your SECOND Llama run (no GPU needed; judging is optional, ~$1-3).

What it does (each lever is independent):
  1. ALL clusters:  uses every cluster in labeled_data.csv (~116) instead of only the ~80 in train+val, because you now
                    evaluate on the 500-item workload and no longer need your own test split.
  2. Leakage guard: drops any cluster whose shown tickets also appear in the workload (exact text, NFKC+casefold).
  3. --judge:       scores every (tickets, label) training pair with the same Faithfulness/Relevance/Specificity judge,
                    then for pairs below --min-score asks Haiku for --best-of N alternative labels, judges them, and keeps
                    the best of {original, alternatives}. NOTE: this optimises toward the Haiku judge - say so in the report.
Format is copied from your existing train.jsonl (prompt / completion / cluster_id / prompt_id / variant_id) and VERIFIED by
rebuilding your existing rows and counting exact matches before anything is written.

Typical:
  python build_train_v2.py --labeled-data <.../labeled_data.csv> --ref-data-dir <.../data/processed_raw_n2000_frozen> \
        --workload-dir <workload handoff folder> --out-dir <.../data/processed_all116_v2> --dry-run
  python build_train_v2.py ...same... --judge --best-of 4        (needs ANTHROPIC_API_KEY)
  python build_train_v2.py ...same...                              (levers 1+2 only, free)
"""
import argparse, hashlib, json, os, random, re, sys, unicodedata
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

TICKET_RE = re.compile(r'^Ticket (\d+):[ ]?(.*)$', re.M)
GEN_MODEL = 'claude-haiku-4-5'


def norm(t):
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', t or '')).casefold().strip()


def read_jsonl(p):
    out = []
    for line in open(p, encoding='utf-8'):
        line = line.strip()
        if line:
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return out


def split_prompt(p):
    """head / ticket texts / tail. The user turn ends right after the last ticket, so the last match may run on into
    '<|eot_id|><|start_header_id|>assistant...' on the same line: cut it there."""
    ms = list(TICKET_RE.finditer(p))
    if not ms:
        return None
    tickets = [m.group(2) for m in ms]
    last = ms[-1]
    cut = tickets[-1].find('<|eot_id|>')
    if cut >= 0:
        tickets[-1] = tickets[-1][:cut]
        end = last.start(2) + cut
    else:
        end = last.end()
    return p[:ms[0].start()], tickets, p[end:]


def build_prompt(head, tickets, tail):
    return head + '\n'.join(f'Ticket {i}: {t}' for i, t in enumerate(tickets, 1)) + tail


def chat_parts(prompt):
    m = re.findall(r'<\|start_header_id\|>(system|user)<\|end_header_id\|>\n\n(.*?)<\|eot_id\|>', prompt, re.S)
    d = {r: c for r, c in m}
    system = re.sub(r'^Cutting Knowledge Date:.*?\nToday Date:.*?\n\n', '', d.get('system', ''), flags=re.S).strip()
    return system, d.get('user', '').strip()


def jsonl_cache(path):
    done = {}
    if Path(path).exists():
        for r in read_jsonl(path):
            done[r['k']] = r['v']
    return done


def append_cache(path, k, v):
    with open(path, 'a', encoding='utf-8') as f:
        f.write(json.dumps({'k': k, 'v': v}, ensure_ascii=False) + '\n')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--labeled-data', required=True)
    ap.add_argument('--ref-data-dir', required=True, help='an existing data folder with train.jsonl (format + verification)')
    ap.add_argument('--workload-dir', help='workload handoff folder (leakage guard); strongly recommended')
    ap.add_argument('--out-dir', required=True)
    ap.add_argument('--n-tickets', type=int, default=0, help='tickets per prompt (default: same as your existing rows)')
    ap.add_argument('--val-clusters', type=int, default=11)
    ap.add_argument('--seed', type=int, default=20261122)
    ap.add_argument('--judge', action='store_true')
    ap.add_argument('--best-of', type=int, default=4)
    ap.add_argument('--min-score', type=float, default=4.0, help='composite below this triggers best-of-N')
    ap.add_argument('--drop-below', type=float, default=0.0, help='after best-of-N, drop pairs still below this (default: keep)')
    ap.add_argument('--workers', type=int, default=4)
    ap.add_argument('--max-calls', type=int, default=2500)
    ap.add_argument('--dry-run', action='store_true')
    a = ap.parse_args()
    import pandas as pd
    out = Path(a.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    # ---------------------------------------------------------------- 1. learn the format from your existing rows
    ref = []
    for fn in ('train.jsonl', 'val.jsonl'):
        p = Path(a.ref_data_dir) / fn
        if p.exists():
            ref += read_jsonl(p)
    if not ref:
        sys.exit(f'no train.jsonl/val.jsonl under {a.ref_data_dir}')
    tmpl, ntick, parsed_ref = defaultdict(Counter), Counter(), []
    for r in ref:
        sp = split_prompt(r['prompt'])
        if not sp:
            continue
        head, tk, tail = sp
        tmpl[str(r['prompt_id'])][(head, tail)] += 1
        ntick[len(tk)] += 1
        parsed_ref.append((r, tk))
    templates = {}
    for pid, c in tmpl.items():
        templates[pid] = c.most_common(1)[0][0]
        if len(c) > 1:
            print(f'[format] WARNING {pid}: {len(c)} different template variants in your data; using the most common ({c.most_common(1)[0][1]} rows)')
    n_t = a.n_tickets or ntick.most_common(1)[0][0]
    print(f'[format] {len(ref)} existing rows, prompts {sorted(templates)}, {n_t} tickets per prompt')

    ld = pd.read_csv(a.labeled_data)
    lab_cols = {re.search(r'_P([1-5])$', c).group(1): c for c in ld.columns if re.search(r'^cluster_name_.*_P[1-5]$', c)}
    if len(lab_cols) != 5:
        sys.exit(f'expected 5 label columns cluster_name_*_P1..P5, found {list(lab_cols.values())}')
    clusters = {}
    for cid, g in ld.groupby('cluster_id'):
        g = g.sort_values('ticket_rank_in_cluster')
        clusters[str(cid)] = {'tickets': [str(x).strip() for x in g['ticket_details'].tolist()],
                              'labels': {k: str(g[c].dropna().iloc[0]).strip() for k, c in lab_cols.items() if g[c].notna().any()}}
    print(f'[data] {len(clusters)} clusters in labeled_data.csv')

    # ---------------------------------------------------------------- 2. verify we can rebuild your existing rows exactly
    same_prompt = same_set = same_label = tot = 0
    for r, tk in parsed_ref:
        c = clusters.get(str(r['cluster_id']))
        if not c:
            continue
        tot += 1
        mine = c['tickets'][:len(tk)]
        same_set += set(map(norm, mine)) == set(map(norm, tk))
        h, t_ = templates.get(str(r['prompt_id']), (None, None))
        if h is not None and build_prompt(h, mine, t_) == r['prompt']:
            same_prompt += 1
        lab = c['labels'].get(str(r['prompt_id'])[-1])
        same_label += lab is not None and norm(lab) == norm(r['completion'].replace('<|eot_id|>', ''))
    if tot:
        print(f'[verify] of {tot} existing rows whose cluster is in labeled_data.csv: '
              f'prompt rebuilt EXACTLY {100*same_prompt/tot:.0f}% | same ticket set {100*same_set/tot:.0f}% | same label {100*same_label/tot:.0f}%')
        if same_prompt / tot < 0.9:
            print('[verify] WARNING: <90% exact. Ticket selection/order differs from how your data was built. Inspect before training.')
    else:
        print('[verify] WARNING: no existing row could be matched by cluster_id; format NOT verified')

    # ---------------------------------------------------------------- 3. leakage guard vs the workload
    dropped = {}
    if a.workload_dir:
        hits = sorted(Path(a.workload_dir).rglob('selected_ticket_provenance.json'))
        if not hits:
            sys.exit('selected_ticket_provenance.json not found under --workload-dir')
        wl = {norm(r['ticket']) for r in json.load(open(hits[0], encoding='utf-8'))}
        for cid, c in clusters.items():
            shown = c['tickets'][:n_t]
            n = sum(norm(t) in wl for t in shown)
            if n:
                dropped[cid] = n
        print(f'[leak] dropping {len(dropped)} clusters that share tickets with the workload: {sorted(dropped)}')
    else:
        print('[leak] no --workload-dir: leakage guard SKIPPED')

    # ---------------------------------------------------------------- 4. candidate rows
    rows = []
    for cid, c in clusters.items():
        if cid in dropped:
            continue
        shown = c['tickets'][:n_t]
        for k in '12345':
            pid = f'P{k}'
            if pid not in templates or k not in c['labels']:
                continue
            h, t_ = templates[pid]
            rows.append({'cluster_id': cid, 'prompt_id': pid, 'tickets': shown, 'label': c['labels'][k], 'source': 'original',
                         'prompt': build_prompt(h, shown, t_)})
    print(f'[build] {len(rows)} (cluster, prompt) rows from {len({r["cluster_id"] for r in rows})} clusters')

    # ---------------------------------------------------------------- 5. optional judge + best-of-N
    scores = {}
    if a.judge:
        import rejudge_reffree as rj
        key = os.environ.get('ANTHROPIC_API_KEY')
        pairs = {}
        for r in rows:
            pairs[rj.cand_id(r['tickets'], r['label'])] = {'tickets': r['tickets'], 'candidate_label': r['label']}
        jc_path, gc_path = out / 'judge_cache.jsonl', out / 'gen_cache.jsonl'
        jc, gc = jsonl_cache(jc_path), jsonl_cache(gc_path)
        todo = [k for k in pairs if not jc.get(k)]
        est = len(todo) + 0.35 * len(rows) * a.best_of * 2
        print(f'[judge] {len(pairs)} unique pairs, {len(jc)} cached, {len(todo)} to judge; best-of-{a.best_of} on ~35% of rows '
              f'=> up to ~{int(est)} calls (~${est*0.0011:.2f})')
        if a.dry_run:
            print('[dry-run] stopping before any API call / file writes')
            return
        if not key:
            sys.exit('set ANTHROPIC_API_KEY first')
        if est > a.max_calls * 1.5:
            sys.exit('refusing: estimated calls exceed --max-calls (raise it deliberately)')

        def jdo(cid):
            res = rj.judge_one(cid, pairs[cid], key)
            return cid, res.get('parsed')
        with ThreadPoolExecutor(a.workers) as ex:
            for cid, parsed in ex.map(jdo, todo):
                jc[cid] = parsed
                if parsed:                       # never cache a failed judgment: retried next run
                    append_cache(jc_path, cid, parsed)

        def comp(parsed):
            return None if not parsed else sum(parsed[d] for d in rj.DIMS) / len(rj.DIMS)
        for r in rows:
            r['score'] = comp(jc.get(rj.cand_id(r['tickets'], r['label'])))
        weak = [r for r in rows if r['score'] is None or r['score'] < a.min_score]
        print(f'[judge] original labels: mean {sum(r["score"] or 0 for r in rows)/len(rows):.3f}; {len(weak)} below {a.min_score}')

        def gen(job):
            r, i = job
            gk = hashlib.sha256(f'{r["prompt"]}|{i}'.encode()).hexdigest()
            if gk in gc:
                return r, gc[gk]
            system, user = chat_parts(r['prompt'])
            body = {'model': GEN_MODEL, 'temperature': 1.0, 'max_tokens': 60, 'system': system,
                    'messages': [{'role': 'user', 'content': user}]}
            raw, _ = rj.call_claude(body, key)
            txt = ''.join(c.get('text', '') for c in raw.get('content', []) if c.get('type') == 'text').strip().strip('"\'').rstrip('.')
            gc[gk] = txt
            append_cache(gc_path, gk, txt)
            return r, txt
        jobs = [(r, i) for r in weak for i in range(a.best_of)]
        with ThreadPoolExecutor(a.workers) as ex:
            gens = list(ex.map(gen, jobs))
        cand = defaultdict(set)
        for r, txt in gens:
            if txt and norm(txt) != norm(r['label']):
                cand[id(r)].add(txt)
        newpairs = {}
        for r in weak:
            for txt in cand[id(r)]:
                newpairs[rj.cand_id(r['tickets'], txt)] = {'tickets': r['tickets'], 'candidate_label': txt}
        todo2 = [k for k in newpairs if not jc.get(k)]
        print(f'[best-of-N] {sum(len(v) for v in cand.values())} alternative labels; judging {len(todo2)} new pairs')

        def jdo2(cid):
            res = rj.judge_one(cid, newpairs[cid], key)
            return cid, res.get('parsed')
        with ThreadPoolExecutor(a.workers) as ex:
            for cid, parsed in ex.map(jdo2, todo2):
                jc[cid] = parsed
                if parsed:                       # never cache a failed judgment: retried next run
                    append_cache(jc_path, cid, parsed)
        improved = 0
        for r in weak:
            best_s, best_l = r['score'] if r['score'] is not None else -1, r['label']
            for txt in cand[id(r)]:
                s = comp(jc.get(rj.cand_id(r['tickets'], txt)))
                if s is not None and s > best_s:
                    best_s, best_l = s, txt
            if best_l != r['label']:
                r['orig_label'], r['orig_score'] = r['label'], r['score']
                r['label'], r['score'], r['source'] = best_l, best_s, 'best_of_n'
                improved += 1
        print(f'[best-of-N] replaced {improved} of {len(weak)} weak labels with a better-judged one')
        if a.drop_below:
            before = len(rows)
            rows = [r for r in rows if r['score'] is not None and r['score'] >= a.drop_below]
            print(f'[filter] --drop-below {a.drop_below}: removed {before-len(rows)} pairs')
        print(f'[judge] final labels: mean {sum(r["score"] or 0 for r in rows)/len(rows):.3f}')
    elif a.dry_run:
        print('[dry-run] no judge requested; stopping before file writes')
        return

    # ---------------------------------------------------------------- 6. split by cluster and write
    cids = sorted({r['cluster_id'] for r in rows})
    random.Random(a.seed).shuffle(cids)
    val_ids = set(cids[:a.val_clusters])
    tr = [r for r in rows if r['cluster_id'] not in val_ids]
    va = [r for r in rows if r['cluster_id'] in val_ids]

    def dump(path, rs):
        with open(path, 'w', encoding='utf-8') as f:
            for r in rs:
                f.write(json.dumps({'prompt': r['prompt'], 'completion': r['label'] + '<|eot_id|>', 'cluster_id': r['cluster_id'],
                                    'prompt_id': r['prompt_id'], 'variant_id': '0'}, ensure_ascii=False) + '\n')
    dump(out / 'train.jsonl', tr)
    dump(out / 'val.jsonl', va)
    import csv
    with open(out / 'training_pairs_scored.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['cluster_id', 'prompt_id', 'split', 'label', 'composite', 'source', 'original_label', 'original_composite'])
        for r in rows:
            w.writerow([r['cluster_id'], r['prompt_id'], 'val' if r['cluster_id'] in val_ids else 'train', r['label'],
                        r.get('score'), r['source'], r.get('orig_label', ''), r.get('orig_score', '')])
    rep = {'clusters_total': len(clusters), 'clusters_dropped_overlap': dropped, 'clusters_used': len(cids),
           'train_rows': len(tr), 'val_rows': len(va), 'judge': a.judge, 'min_score': a.min_score if a.judge else None,
           'best_of': a.best_of if a.judge else None, 'seed': a.seed,
           'note': 'labels chosen by the Haiku judge when --judge is used: results are optimised toward that judge'}
    json.dump(rep, open(out / 'build_report.json', 'w'), indent=1)
    print(f'[write] {out}: train {len(tr)} rows ({len(tr)//5} clusters), val {len(va)} rows ({len(va)//5} clusters)')
    print('[next] train with your existing notebook pointed at this folder, then run run_workload.py with --train-data-dir this folder')


if __name__ == '__main__':
    main()
