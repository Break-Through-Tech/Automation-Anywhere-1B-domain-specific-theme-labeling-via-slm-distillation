#!/usr/bin/env python3
"""
make_pipeline_inputs.py -- feed the judge-cleaned labels through YOUR OWN pipeline (dataset.py builds train/val/test from
bitext_labeled.csv + a cluster-level split), instead of hand-writing train.jsonl (which the pipeline overwrites).

  build : copy <base-data-dir>/bitext_*.csv -> <out-dir>, keep only the clusters in training_pairs_scored.csv (the leak-free
          set from build_train_v2.py) and replace each cluster's P1..P5 label with the final (best-of-N) label.
          Writes NO jsonl: the pipeline creates those. Verifies the untouched labels still equal the originals.
  verify: after the pipeline has trained, check <out-dir>/train.jsonl+val.jsonl: label match vs the scored file, and that no
          ticket in them appears in the workload.

  python make_pipeline_inputs.py build  --base-data-dir .../processed_raw_n2000_frozen --scored-csv .../processed_all116_v2/training_pairs_scored.csv --out-dir .../processed_all112_v2
  python make_pipeline_inputs.py verify --out-dir .../processed_all112_v2 --scored-csv ... --workload-dir <handoff>
"""
import argparse, json, re, shutil, sys, unicodedata
from pathlib import Path
import pandas as pd


def norm(t):
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', str(t or ''))).casefold().strip()


def label_cols(df):
    cols = {re.search(r'_P([1-5])$', c).group(1): c for c in df.columns if re.search(r'^cluster_name_.*_P[1-5]$', c)}
    if len(cols) != 5:
        sys.exit(f'expected 5 label columns cluster_name_*_P1..P5, found {list(cols.values())}')
    return cols


def build(a):
    base, out = Path(a.base_data_dir), Path(a.out_dir)
    scored = pd.read_csv(a.scored_csv)
    scored['cluster_id'] = scored['cluster_id'].astype(int)
    keep = sorted(scored['cluster_id'].unique())
    lab = pd.read_csv(base / 'bitext_labeled.csv')
    cols = label_cols(lab)
    allc = set(lab['cluster_id'].astype(int))
    missing = set(keep) - allc
    if missing:
        sys.exit(f'clusters in the scored file but not in bitext_labeled.csv: {sorted(missing)[:10]}')
    dropped = sorted(allc - set(keep))
    print(f'[build] {len(allc)} clusters in base data; keeping {len(keep)}; dropping {len(dropped)}: {dropped}')

    # sanity: untouched labels must equal the originals (otherwise the scored file came from a different pool)
    final = {(int(r.cluster_id), str(r.prompt_id)[-1]): r.label for r in scored.itertuples()}
    orig = {}
    for r in scored.itertuples():
        orig[(int(r.cluster_id), str(r.prompt_id)[-1])] = r.original_label if isinstance(r.original_label, str) and r.original_label else r.label
    first = lab.groupby('cluster_id').first()
    n = ok = 0
    for (cid, k), o in orig.items():
        n += 1
        ok += norm(first.loc[cid, cols[k]]) == norm(o)
    print(f'[build] sanity: {ok}/{n} original labels in {base.name} match the scored file ({100*ok/max(1,n):.1f}%)')
    if ok / max(1, n) < 0.98:
        sys.exit('the scored file does not match this base data: wrong --base-data-dir? (refusing)')

    out.mkdir(parents=True, exist_ok=True)
    new = lab[lab['cluster_id'].astype(int).isin(keep)].copy()
    changed = 0
    for (cid, k), lbl in final.items():
        m = new['cluster_id'].astype(int) == cid
        if norm(new.loc[m, cols[k]].iloc[0]) != norm(lbl):
            changed += 1
        new.loc[m, cols[k]] = lbl
    new.to_csv(out / 'bitext_labeled.csv', index=False)
    for fn in ('bitext_clustered.csv', 'bitext_grouped.csv'):
        p = base / fn
        if p.exists():
            d = pd.read_csv(p)
            if 'cluster_id' in d.columns:
                d = d[d['cluster_id'].astype(int).isin(keep)]
            d.to_csv(out / fn, index=False)
    for stale in ('train.jsonl', 'val.jsonl', 'test.jsonl', 'cluster_splits.json'):
        (out / stale).unlink(missing_ok=True)
    print(f'[build] wrote {out}: {len(keep)} clusters, {len(new)} ticket rows, {changed} (cluster,prompt) labels replaced by best-of-N')
    print('[build] no jsonl written on purpose: your pipeline builds it. Set cfg["split"] to ~0.90/0.08/0.02.')


def verify(a):
    out = Path(a.out_dir)
    scored = pd.read_csv(a.scored_csv)
    final = {(str(int(r.cluster_id)), str(r.prompt_id)): r.label for r in scored.itertuples()}
    wl = set()
    if a.workload_dir:
        hits = sorted(Path(a.workload_dir).rglob('selected_ticket_provenance.json'))
        wl = {norm(r['ticket']) for r in json.load(open(hits[0], encoding='utf-8'))}
    tot = match = leak = 0
    clusters = {}
    for fn in ('train.jsonl', 'val.jsonl'):
        for line in open(out / fn, encoding='utf-8'):
            r = json.loads(line)
            tot += 1
            lbl = r['completion'].replace('<|eot_id|>', '').strip()
            exp = final.get((str(r['cluster_id']), str(r['prompt_id'])))
            match += exp is not None and norm(exp) == norm(lbl)
            for t in re.findall(r'^Ticket \d+: ?(.*?)(?:<\|eot_id\|>.*)?$', r['prompt'], re.M):
                if norm(t) in wl:
                    leak += 1
            clusters.setdefault(fn, set()).add(r['cluster_id'])
    print(f'[verify] rows {tot} (train {len(clusters.get("train.jsonl", ()))} clusters, val {len(clusters.get("val.jsonl", ()))}); '
          f'label == my final label: {match}/{tot} ({100*match/max(1,tot):.1f}%) | ticket lines found in the workload: {leak}')
    ok = match / max(1, tot) > 0.99 and leak == 0
    print('[verify] PASS' if ok else '[verify] FAIL: do NOT evaluate this adapter')
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('mode', choices=['build', 'verify'])
    ap.add_argument('--base-data-dir')
    ap.add_argument('--scored-csv', required=True)
    ap.add_argument('--out-dir', required=True)
    ap.add_argument('--workload-dir')
    a = ap.parse_args()
    build(a) if a.mode == 'build' else verify(a)
