#!/usr/bin/env python3
"""
run_workload.py -- evaluate YOUR fine-tuned adapter (and its baseline) on the frozen 100-cluster x 5-prompt workload
(500 items per model), reusing the saved Haiku teacher outputs as the shared reference. NO retraining.

Why: your own test sets are 4-7 clusters (20-35 items). The workload is 100 clusters (500 items), so results are
comparable with the shared evaluation files and the statistics become meaningful.

Stages (each resumable, nothing inside your run folder is modified):
  overlap   CPU  exact-text leakage check: the 1,000 workload tickets vs the tickets your adapter was TRAINED on (train+val)
  generate  GPU  baseline (adapter off) and fine-tuned (adapter on), batch 1, greedy, 60 new tokens; saves every item
  assemble  CPU  builds <out>/workload_17col.csv in the 17-column format (judge columns blank; similarity filled
                 with the shared settings: mpnet cosine, ROUGE-L stem, BERTScore roberta-large L17 vs the teacher label)
  [then run rejudge_reffree.py on workload_17col.csv  -> workload_17col_rejudged.csv]
  finalize  CPU  writes ancheng_format_full500.csv + ancheng_format_nooverlap.csv, prints means and paired cluster-bootstrap
                 lifts (fine-tuned minus baseline, 95% CI over clusters)

Prompts: the 5 user templates + the workload tickets, with YOUR adapter's trained system message (taken from your train data's
test.jsonl) so the model sees the format it was fine-tuned on. Both baseline and fine-tuned get the identical prompt.

Typical:
  python run_workload.py --stage all --run-dir <.../outputs/<run_id>> --workload-dir <workload folder> \
         --train-data-dir <.../data/processed_raw_domain> --out-dir <.../consolidated/workload_confirm_v2>
"""
import argparse, ast, csv, json, random, re, sys, time, unicodedata
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from remeasure_latency import resolve_base_id, load_models, eos_ids, generate_one          # GPU helpers (lazy torch imports inside)
import build_17col as b17                                                   # recompute_similarity, COLUMNS, parse_prompt

csv.field_size_limit(10 ** 9)
COLS = b17.COLUMNS
RATE = 0.526


def read_jsonl(p):
    out = []
    for line in open(p, encoding='utf-8'):
        line = line.strip()
        if line:
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return out


def norm(t):
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', t or '')).casefold().strip()


def find_one(root, name):
    hits = sorted(Path(root).rglob(name))
    if not hits:
        sys.exit(f'{name} not found under {root}')
    return hits[0]


# ------------------------------------------------------------------------------------------------ workload
def load_workload(wdir):
    import yaml
    items = json.load(open(find_one(wdir, 'evaluation_inputs.json'), encoding='utf-8'))
    cfg = yaml.safe_load(open(find_one(wdir, 'serving_config.yaml'), encoding='utf-8'))
    prov = json.load(open(find_one(wdir, 'selected_ticket_provenance.json'), encoding='utf-8'))
    teach = {}
    for r in read_jsonl(find_one(wdir, 'teacher_requests.jsonl')):
        teach[(str(r['cluster_id']), str(r['prompt_id']))] = r
    templates = {k: cfg['prompts'][k] for k in ('P1', 'P2', 'P3', 'P4', 'P5')}
    return items, templates, cfg['prompts']['system'].strip(), prov, teach


def trained_system_text(data_dir):
    """the exact system message your adapter was trained with (from the run's data folder)"""
    for fn in ('test.jsonl', 'train.jsonl'):
        p = Path(data_dir) / fn
        if p.exists():
            for r in read_jsonl(p):
                msgs, _ = b17.parse_prompt(r['prompt'])
                s = next((m['content'] for m in msgs if m['role'] == 'system'), None)
                if s:
                    return s, r['prompt']
    return None, None


def make_messages(system, template, tickets):
    block = '\n'.join(f'Ticket {i}: {t}' for i, t in enumerate(tickets, 1))
    return [{'role': 'system', 'content': system}, {'role': 'user', 'content': template.replace('{tickets}', block)}]


# ------------------------------------------------------------------------------------------------ overlap
def training_tickets(data_dir):
    tk = set()
    for fn in ('train.jsonl', 'val.jsonl'):
        p = Path(data_dir) / fn
        if p.exists():
            for r in read_jsonl(p):
                for t in re.findall(r'^Ticket \d+:\s*(.*)$', r.get('prompt', ''), re.M):
                    tk.add(norm(t))
    return tk


def overlap_stage(prov, data_dir, out_dir):
    if not data_dir:
        print('[overlap] no --train-data-dir: SKIPPED (cannot tell which workload clusters your adapter saw)')
        return {}
    train = training_tickets(data_dir)
    per = defaultdict(int)
    hit = 0
    clusters = {r['cluster_id'] for r in prov}
    for r in prov:
        if norm(r['ticket']) in train:
            per[r['cluster_id']] += 1
            hit += 1
    rep = {'train_data_dir': str(data_dir), 'n_train_tickets': len(train), 'workload_tickets': len(prov),
           'overlapping_tickets': hit, 'clusters_with_overlap': dict(sorted(per.items())),
           'n_clean_clusters': len(clusters) - len(per), 'n_clusters': len(clusters),
           'definition': 'NFKC + casefold + whitespace normalisation, exact text match; near-duplicate paraphrases NOT detected'}
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    json.dump(rep, open(Path(out_dir) / 'overlap_report.json', 'w'), indent=1)
    print(f"[overlap] {hit} of {len(prov)} workload tickets also appear in your training data; "
          f"{len(per)} of {len(clusters)} clusters affected, {rep['n_clean_clusters']} clean -> overlap_report.json")
    return rep


# ------------------------------------------------------------------------------------------------ generate
def check_format(tok, stored_prompt):
    """does tokenizer.apply_chat_template reproduce the prompt string your adapter was trained on?"""
    try:
        msgs, _ = b17.parse_prompt(stored_prompt)
        mine = tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
        strip = lambda s: re.sub(r'Today Date:[^\n]*\n', '', s)
        if strip(mine).strip() == strip(stored_prompt).strip():
            print('[format] chat-template rendering matches your training prompts (ignoring the date line): OK')
        else:
            print('[format] WARNING: rendered prompt differs from your training prompt format; check before trusting results')
            print('   mine  :', repr(strip(mine)[-160:]))
            print('   stored:', repr(strip(stored_prompt)[-160:]))
    except Exception as e:
        print('[format] check skipped:', type(e).__name__, e)


def generate_stage(a, items, templates, system, out_dir):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    raw_p = out_dir / 'raw_generations.jsonl'
    done = {}
    if raw_p.exists():
        for r in read_jsonl(raw_p):
            done[(r['role'], r['cluster_id'], r['prompt_id'])] = r
    run_dir = Path(a.run_dir)
    adapter = run_dir / 'models' / 'lora_adapter'
    if not adapter.exists():
        sys.exit(f'no adapter at {adapter}')
    import torch
    print('GPU:', torch.cuda.get_device_name(0))
    model, tok, base_id = load_models(adapter, a.dtype, a.load_4bit, a.base_model)
    eos = eos_ids(tok)
    msgs = {(it['cluster_id'], it['prompt_id']): make_messages(system, templates[it['prompt_id']], it['tickets']) for it in items}
    prompts = {k: tok.apply_chat_template(m, tokenize=False, add_generation_prompt=True) for k, m in msgs.items()}
    if a.stored_prompt:
        check_format(tok, a.stored_prompt)
    order = list(items)
    random.Random(a.seed).shuffle(order)
    if a.limit:
        order = order[:a.limit]
    meta = {'base_model': base_id, 'dtype': a.dtype, 'load_4bit': a.load_4bit, 'seed': a.seed, 'gpu': torch.cuda.get_device_name(0)}
    json.dump(meta, open(out_dir / 'generation_meta.json', 'w'))

    def run_role(role):
        todo = [it for it in order if (role, it['cluster_id'], it['prompt_id']) not in done]
        print(f'[{role}] {len(todo)} to generate ({len(order) - len(todo)} already saved)')
        if not todo:
            return
        for it in order[:a.warmup]:
            generate_one(model, tok, prompts[(it['cluster_id'], it['prompt_id'])], a.max_new_tokens, eos)
        with open(raw_p, 'a', encoding='utf-8') as f:
            for n, it in enumerate(todo, 1):
                k = (it['cluster_id'], it['prompt_id'])
                label, dt = generate_one(model, tok, prompts[k], a.max_new_tokens, eos)
                rec = {'role': role, 'cluster_id': k[0], 'prompt_id': k[1], 'label': label, 'latency_s': dt}
                f.write(json.dumps(rec, ensure_ascii=False) + '\n')
                f.flush()
                done[(role,) + k] = rec
                if n % 50 == 0:
                    print(f'  {role}: {n}/{len(todo)}', flush=True)

    with model.disable_adapter():
        run_role('baseline')
    run_role('finetuned')
    return base_id


# ------------------------------------------------------------------------------------------------ assemble
def teacher_usage(r):
    s = str(r.get('raw_response', ''))
    i, o = re.search(r"'input_tokens':\s*(\d+)", s), re.search(r"'output_tokens':\s*(\d+)", s)
    return (int(i.group(1)), int(o.group(1))) if i and o else (None, None)


def assemble_stage(a, items, templates, system, teach, out_dir, names, owner):
    out_dir = Path(out_dir)
    raw = {}
    for r in read_jsonl(out_dir / 'raw_generations.jsonl'):
        raw[(r['role'], r['cluster_id'], r['prompt_id'])] = r
    recs = []
    miss = 0
    for role in ('baseline', 'finetuned'):
        for it in items:
            k = (it['cluster_id'], it['prompt_id'])
            g = raw.get((role,) + k)
            if g is None:
                miss += 1
                continue
            t = teach.get(k)
            msgs = make_messages(system, templates[it['prompt_id']], it['tickets'])
            rec = dict.fromkeys(COLS, '')
            rec.update({'Name of Model': names[role], 'Model Owner': owner, 'Prompt ID': k[1],
                        'Actual Prompt': json.dumps(msgs, ensure_ascii=False),
                        'Input to the Model': json.dumps(it['tickets'], ensure_ascii=False),
                        'Output of the Model': g['label'], 'Latency': repr(g['latency_s']), 'Batch': 'NO', 'Batch Size': 1,
                        'Estimated/Approx Cost': repr(g['latency_s'] * RATE / 3600.0)})
            recs.append((rec, {'role': role, 'cluster_id': k[0], 'reference_label': (t or {}).get('label', '')}))
    if miss:
        print(f'WARNING: {miss} items have no generation yet (run the generate stage to completion)')
    for it in items:                      # teacher rows: the saved Haiku outputs, latency and token usage
        k = (it['cluster_id'], it['prompt_id'])
        t = teach.get(k)
        if not t:
            continue
        ti, to = teacher_usage(t)
        tm = t['request_messages']                    # a list in the handoff file; older logs store it as a string
        if isinstance(tm, str):
            try:
                tm = ast.literal_eval(tm)
            except Exception:
                tm = json.loads(tm)
        lat = float(t['latency_s'])
        rec = dict.fromkeys(COLS, '')
        rec.update({'Name of Model': names['teacher'], 'Model Owner': owner, 'Prompt ID': k[1],
                    'Actual Prompt': json.dumps(tm, ensure_ascii=False), 'Input to the Model': json.dumps(it['tickets'], ensure_ascii=False),
                    'Output of the Model': t['label'], 'Latency': repr(lat), 'Batch': 'NO', 'Batch Size': 1,
                    'Cosine Score': '1.0', 'ROUGE': '1.0', 'BertScore': '1.0',
                    'Estimated/Approx Cost': repr((ti * 1 + to * 5) / 1e6) if ti is not None else ''})
        recs.append((rec, {'role': 'teacher', 'cluster_id': k[0], 'reference_label': t['label']}))
    empty = sum(1 for r, p in recs if p['role'] != 'teacher' and not r['Output of the Model'].strip())
    if empty:
        print(f'WARNING: {empty} student outputs are empty')
    if not a.skip_sim:
        sim_items = [(r, {**p, 'similarity_source': ''}) for r, p in recs]
        b17.recompute_similarity(sim_items, print)
    dest = out_dir / 'workload_17col.csv'
    with open(dest, 'w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=COLS)
        w.writeheader()
        for r, _ in recs:
            w.writerow({c: ('' if r[c] is None else r[c]) for c in COLS})
    with open(out_dir / 'workload_row_map.csv', 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(['csv_line', 'role', 'cluster_id', 'prompt_id'])
        for i, (r, p) in enumerate(recs, start=2):
            w.writerow([i, p['role'], p['cluster_id'], r['Prompt ID']])
    print(f'wrote {dest} ({len(recs)} rows). Next: rejudge_reffree.py on it (about $1-2).')


# ------------------------------------------------------------------------------------------------ finalize
def f_(x):
    try:
        return float(x)
    except Exception:
        return None


def finalize_stage(out_dir, names, overlap_rep, seed=0):
    import numpy as np
    out_dir = Path(out_dir)
    src = out_dir / 'workload_17col_rejudged.csv'
    if not src.exists():
        sys.exit(f'{src.name} not found: run rejudge_reffree.py on workload_17col.csv first')
    rows = list(csv.DictReader(open(src, encoding='utf-8', newline='')))
    rmap = list(csv.DictReader(open(out_dir / 'workload_row_map.csv', encoding='utf-8')))
    assert len(rows) == len(rmap)
    for r, m in zip(rows, rmap):
        r['_cluster'], r['_role'] = m['cluster_id'], m['role']
    bad = set((overlap_rep or {}).get('clusters_with_overlap', {}))
    metrics = [('Faithfulness', 'F'), ('Relevance', 'R'), ('Specificity', 'S'), ('Composite', 'comp'),
               ('Cosine Score', 'cos'), ('ROUGE', 'rougeL'), ('BertScore', 'bert'), ('Latency', 'lat')]
    rng = np.random.default_rng(seed)

    def report(rs, label, dest):
        order = {'baseline': 0, 'finetuned': 1, 'teacher': 2}
        rs = sorted(rs, key=lambda r: (order[r['_role']], r['_cluster'], r['Prompt ID']))
        with open(dest, 'w', encoding='utf-8', newline='') as f:
            w = csv.DictWriter(f, fieldnames=COLS)
            w.writeheader()
            w.writerows([{c: r[c] for c in COLS} for r in rs])
        ncl = len({r['_cluster'] for r in rs})
        print(f'\n=== {label}: {len(rs)} rows, {ncl} clusters -> {dest.name}')
        print(f"{'config':74s} {'n':>4s} " + ' '.join(f'{k[1]:>6s}' for k in metrics) + f" {'$/1k':>7s}")
        for role in ('baseline', 'finetuned', 'teacher'):
            rr = [r for r in rs if r['_role'] == role]
            vals = []
            for col, _ in metrics:
                v = [f_(r[col]) for r in rr if f_(r[col]) is not None]
                vals.append(sum(v) / len(v) if v else float('nan'))
            c = [f_(r['Estimated/Approx Cost']) for r in rr if f_(r['Estimated/Approx Cost']) is not None]
            print(f"{names[role][:74]:74s} {len(rr):4d} " + ' '.join(f'{v:6.3f}' for v in vals) + f" {1000 * sum(c) / max(1, len(c)):7.4f}")
        # paired lifts over clusters (fine-tuned minus baseline), bootstrap over clusters
        by = defaultdict(lambda: defaultdict(list))
        for r in rs:
            if r['_role'] in ('baseline', 'finetuned'):
                for col, _ in metrics:
                    v = f_(r[col])
                    if v is not None:
                        by[(r['_role'], col)][r['_cluster']].append(v)
        print('paired lift (fine-tuned - baseline), 95% CI by resampling clusters; up/down = clusters where fine-tuned is higher/lower')
        for col, short in metrics[:-1]:
            cl = sorted(set(by[('baseline', col)]) & set(by[('finetuned', col)]))
            if len(cl) < 3:
                continue
            d = np.array([np.mean(by[('finetuned', col)][c]) - np.mean(by[('baseline', col)][c]) for c in cl])
            boots = rng.choice(d, size=(10000, len(d)), replace=True).mean(axis=1)
            lo, hi = np.percentile(boots, [2.5, 97.5])
            print(f'  {short:7s} {d.mean():+.3f}  CI [{lo:+.3f}, {hi:+.3f}]  clusters up/down {int((d > 0).sum())}/{int((d < 0).sum())} of {len(d)}'
                  + ('   <- excludes 0' if lo > 0 or hi < 0 else ''))

    report(rows, 'FULL workload', out_dir / 'ancheng_format_full500.csv')
    if bad:
        clean = [r for r in rows if r['_cluster'] not in bad]
        report(clean, 'NO-OVERLAP clusters only (your adapter never saw these exact tickets)', out_dir / 'ancheng_format_nooverlap.csv')


# ------------------------------------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--stage', default='all', choices=['all', 'overlap', 'generate', 'assemble', 'finalize'])
    ap.add_argument('--run-dir', help='.../outputs/<run_id> containing models/lora_adapter')
    ap.add_argument('--workload-dir', required=True, help='workload folder (frozen inputs, serving_config.yaml, teacher log)')
    ap.add_argument('--train-data-dir', help='data folder the adapter was trained from (has train.jsonl/val.jsonl/test.jsonl)')
    ap.add_argument('--out-dir', required=True)
    ap.add_argument('--owner', default='vd35')
    ap.add_argument('--dtype', default='bf16', choices=['bf16', 'fp16'])
    ap.add_argument('--load-4bit', action='store_true')
    ap.add_argument('--max-new-tokens', type=int, default=60)
    ap.add_argument('--warmup', type=int, default=3)
    ap.add_argument('--limit', type=int, default=0, help='debug: only N items')
    ap.add_argument('--seed', type=int, default=20261120)
    ap.add_argument('--system-text', default=None, help='override the trained system message')
    ap.add_argument('--model-id', default=None)
    ap.add_argument('--base-model', default=None, help='HF id of the base model if adapter_config.json has null (default: inferred, e.g. meta-llama/Llama-3.2-3B-Instruct)')
    ap.add_argument('--skip-sim', action='store_true', help='skip the cosine/ROUGE/BERTScore computation (testing only)')
    a = ap.parse_args()

    items, templates, his_system, prov, teach = load_workload(a.workload_dir)
    print(f'workload: {len(items)} items, {len({i["cluster_id"] for i in items})} clusters, teacher refs {len(teach)}')
    system, a.stored_prompt = (a.system_text, None) if a.system_text else trained_system_text(a.train_data_dir) if a.train_data_dir else (None, None)
    if not system:
        print('WARNING: trained system message not found; using the shared system message (no domain anchor)')
        system = his_system
    elif system.strip() != his_system.strip():
        print('system message: YOUR adapter\'s trained version (differs from the shared config by the domain-anchor sentence) - used for baseline AND fine-tuned')
    out = Path(a.out_dir)
    mid = a.model_id
    if not mid and a.run_dir:
        mid = resolve_base_id(Path(a.run_dir) / 'models' / 'lora_adapter', a.base_model)
    mid = mid or 'model'
    names = {'baseline': f'{mid} (baseline, Colab T4, batch size 1)',
             'finetuned': f'{mid} (fine-tuned, LoRA adapter, Colab T4, batch size 1)', 'teacher': 'claude-haiku-4-5 (teacher)'}
    st = a.stage
    rep = {}
    if st in ('all', 'overlap', 'finalize'):
        rep = overlap_stage(prov, a.train_data_dir, out) if st != 'finalize' else (
            json.load(open(out / 'overlap_report.json')) if (out / 'overlap_report.json').exists() else {})
    if st in ('all', 'generate'):
        if not a.run_dir:
            sys.exit('--run-dir required')
        generate_stage(a, items, templates, system, out)
    if st in ('all', 'assemble'):
        assemble_stage(a, items, templates, system, teach, out, names, a.owner)
    if st == 'finalize':
        finalize_stage(out, names, rep)


if __name__ == '__main__':
    main()
