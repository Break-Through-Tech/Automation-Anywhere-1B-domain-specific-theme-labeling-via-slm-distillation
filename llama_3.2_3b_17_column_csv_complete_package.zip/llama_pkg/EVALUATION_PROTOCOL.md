# Evaluation protocol (what was run)

**Inputs.** 500 frozen inputs: 100 clusters x 5 prompts, ten ordered tickets per cluster. Four configurations of 500 rows each: untuned Llama 3.2-3B-Instruct, Label-80, Label-108, and the Claude Haiku 4.5 teacher. 2,000 records.

**Students.** Base `unsloth/Llama-3.2-3B-Instruct` with the LoRA adapter loaded unmerged (transformers + PEFT). The untuned row is the same model with the adapter disabled.
Prompt = chat template + the training system message + one of five user templates, tickets listed as "Ticket 1: ..." to "Ticket 10: ...". Greedy decoding, KV cache, up to 60 new tokens.
One input at a time, seeded shuffled order (seed 20261120), 3 untimed warmup generations. Latency = tokenize + transfer + generate + decode, GPU synchronized; loading and disk writes excluded.

**Teacher.** The 500 saved Haiku 4.5 outputs, with their latency and token counts (temperature 0.3, 60-token cap). Reused, not re-run.

**Quality.** Blinded, reference-free Haiku 4.5 judge (temperature 0), scoring Faithfulness, Relevance and Specificity from 1 to 5 against all ten tickets (`judge_system_prompt.txt`).
One judgment per unique ticket-list/label pair (1,478 unique pairs), reasons kept in the judge cache. Composite = mean of the three.
Similarity (cosine, ROUGE-L, BERTScore) compares each label with the teacher label for the same cluster and prompt (`metric_settings.json`).

**Overlap.** Exact-text match (NFKC, casefold, whitespace) between the 1,000 test tickets and each adapter's training tickets: Label-80 2 matches in 2 clusters; Label-108 none.

**Uncertainty.** Cluster-level bootstrap, 10,000 resamples, five prompts kept together.
Label-108 over Label-80: composite +0.199, 95% CI [+0.098, +0.313]. Label-108 over untuned: +0.545, CI [+0.423, +0.673].

**Cost.** Students: latency x $0.526 / 3600 (rented T4 at full use). Teacher: logged tokens at $1 in / $5 out per million. Training, loading, idle time and judging are not included.
