# Known limitations

## How the Llama runs were measured
- **One label at a time.** Every row is batch size 1. There is no batch test and no merged-adapter timing yet, so speed and cost are the slowest case.
- **Plain transformers + PEFT, adapter not merged.** The untuned baseline is the same model with the adapter switched off, so it is not a plain base-model timing. The script default is bf16, which a T4 does not run natively (the dtype actually used is in `generation_meta.json`).
- **Student prompts have one extra sentence.** The system message used in training starts with "You are analysing IT support tickets." The shared `serving_config.yaml` and the teacher log do not, so the teacher did not see it.
- **Teacher rows are saved results**, not re-run. Teacher latency includes the network round trip and is not a throughput figure.

## Comparing the two adapters
- **Different sessions.** Label-80 was run and judged earlier than the untuned baseline and Label-108 (the baseline scored 3.984 then, 3.991 now). Latency also moved (baseline 1.29 s then, 1.14 s now), so compare latency only within one run.
- **More than labels changed.** Label-80 had 179 distinct training tickets in the overlap check; Label-108 had 980. Label-108 also dropped overlapping clusters and swapped 37 labels. We did not measure each change separately.
- **Judge.** Haiku is both teacher and judge, and the 37 swapped labels were chosen with that judge, so some of the gain may favour this judge. It has not been checked against human ratings.
- **Overlap is exact-text only.** Label-80: 2 of 1,000 test tickets (2 clusters). Label-108: 0. Paraphrases are not detected.
- **One training run per adapter.** Label-108's step count (about 93) is computed from the row count; the notebook saves `training_log.txt` to record the real number.
- **Metric model revisions** were not saved by the Llama run (`metric_settings.json` is the shared setting).

## Fixed along the way
- Earlier CSV exports had `[]` in Actual Prompt for all 500 teacher rows. Fixed in `scripts/run_workload.py` and `combine_runs.py`; scores and labels were not affected.
- A first attempt at Label-108 used the wrong split and trained for 12 steps. It is not used anywhere here.

## Not in the ZIP
Adapter and base-model weights, raw generations, judge caches and training data. `collect_from_drive.py` copies them from your Drive and records adapter hashes.
