"""Portable CSV exporter for the saved matrix; requires only Python's standard library.

Writes the 17-column CSV from the saved records. Never calls a model or API.
"""
import argparse
import csv
import json
import math
from pathlib import Path

HEADERS = ['Name of Model', 'Model Owner', 'Prompt ID', 'Actual Prompt',
           'Input to the Model', 'Output of the Model', 'Latency', 'Batch',
           'Batch Size', 'Faithfulness', 'Relevance', 'Specificity', 'Composite',
           'Cosine Score', 'ROUGE', 'BertScore', 'Estimated/Approx Cost']


def export_csv(source, destination, expected_rows=None):
    matrix = json.loads(Path(source).read_text(encoding='utf-8'))
    if not matrix or matrix[0] != HEADERS:
        raise ValueError('The matrix must start with the exact 17-column header')
    if expected_rows is not None and len(matrix) - 1 != expected_rows:
        raise ValueError(f'Expected {expected_rows} records; found {len(matrix)-1}')
    for line, row in enumerate(matrix[1:], 2):
        if len(row) != 17 or any(v is None or v == '' for v in row):
            raise ValueError(f'Missing field or wrong width at row {line}')
        for i in [6, 8, 9, 10, 11, 12, 13, 14, 15, 16]:
            if type(row[i]) not in (int, float) or not math.isfinite(row[i]):
                raise ValueError(f'Invalid numeric field at row {line}, column {i+1}')
        if any(type(row[i]) is not int or not 1 <= row[i] <= 5 for i in [9, 10, 11]):
            raise ValueError(f'Invalid judge score at row {line}')
        if not math.isclose(row[12], sum(row[9:12])/3, rel_tol=0, abs_tol=1e-12):
            raise ValueError(f'Composite mismatch at row {line}')
        if type(row[8]) is not int or row[8] < 1:
            raise ValueError(f'Invalid actual batch size at row {line}')
        if row[7] != ('YES' if row[8] > 1 else 'NO'):
            raise ValueError(f'Batch flag mismatch at row {line}')
        if row[6] <= 0 or row[16] < 0:
            raise ValueError(f'Invalid latency or cost at row {line}')
    destination = Path(destination)
    if destination.exists():
        raise FileExistsError(f'Refusing to replace existing file: {destination}')
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('x', encoding='utf-8', newline='') as handle:
        csv.writer(handle, lineterminator='\r\n').writerows(matrix)
    return len(matrix)-1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('matrix_json', help='Path to raw_records_matrix.json')
    parser.add_argument('output_csv', help='A new output filename')
    parser.add_argument('--expected-rows', type=int)
    args = parser.parse_args()
    count = export_csv(args.matrix_json, args.output_csv, args.expected_rows)
    print(f'Exported {count} records and 17 columns to {args.output_csv}')
