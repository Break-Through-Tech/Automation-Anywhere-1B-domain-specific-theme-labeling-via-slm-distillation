"""Check the exported Llama CSV against the saved source records, not only its own arithmetic.

   python3 validate_llama_csv.py [CSV]      (default: llama_3.2_3b_17_columns_2000rows.csv next to this file)

Always checked (needs only files in this folder): 2,000 rows x 17 columns, header, 4 configurations x 500 unique
cluster/prompt keys, tickets equal the frozen workload, teacher labels / messages / cost equal teacher_requests.jsonl,
composite = mean of the three judge scores, batch flags, latency/cost arithmetic, provenance alignment, metric ranges.
Checked when present in source_records/ (added by collect_from_drive.py):
   <run>/raw_generations.jsonl  -> every student output equals the logged generation and latency
   <run>/*_rejudge_cache.jsonl  -> every judge score equals the cached Haiku judgment for that ticket/label pair
Writes CSV_VALIDATION.json.
"""
import collections, csv, hashlib, json, math, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
csv.field_size_limit(10 ** 9)
RATE = 0.526
RUNS = {'llama_label80': 'label80', 'llama_label108': 'label108', 'llama_baseline': 'label108'}   # model_key -> source folder
ROLE = {'llama_baseline': 'baseline', 'llama_label80': 'finetuned', 'llama_label108': 'finetuned'}


def jl(p):
    return [json.loads(l) for l in Path(p).read_text(encoding='utf-8').splitlines() if l.strip()]


def usage(t):
    r = t['raw_response']
    if isinstance(r, dict):
        u = r['usage']
        return u['input_tokens'], u['output_tokens']
    s = str(r)
    return int(re.search(r"'input_tokens':\s*(\d+)", s).group(1)), int(re.search(r"'output_tokens':\s*(\d+)", s).group(1))


def main():
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / 'llama_3.2_3b_17_columns_2000rows.csv'
    matrix = json.loads((ROOT / 'raw_records_matrix.json').read_text(encoding='utf-8'))
    prov = json.loads((ROOT / 'row_provenance.json').read_text(encoding='utf-8'))
    work = json.loads((ROOT / 'evaluation_inputs.json').read_text(encoding='utf-8'))
    source = {(r['cluster_id'], r['prompt_id']): r for r in work}
    teacher = {(t['cluster_id'], t['prompt_id']): t for t in jl(ROOT / 'teacher_requests.jsonl')}
    assert len(source) == 500 and len({r['cluster_id'] for r in work}) == 100 and len(teacher) == 500
    with path.open(newline='', encoding='utf-8') as f:
        reader = csv.reader(f)
        header = next(reader)
        rows = list(reader)
    assert header == matrix[0] and len(header) == 17
    assert len(rows) == len(prov) == len(matrix) - 1 == 2000
    groups, notes = collections.defaultdict(list), []
    for line, (row, m, exp) in enumerate(zip(rows, prov, matrix[1:]), 2):
        assert len(row) == 17 and m['csv_row'] == line and all(v != '' for v in row)
        key = (m['cluster_id'], m['prompt_id'])
        item = source[key]
        assert row[2] == key[1] and json.loads(row[4]) == item['tickets']
        assert row[5] == exp[5] and json.loads(row[3]) == json.loads(exp[3])
        assert row[1] == exp[1]
        nums = {i: float(row[i]) for i in (6, 8, 9, 10, 11, 12, 13, 14, 15, 16)}
        assert all(math.isfinite(x) for x in nums.values())
        for i in nums:
            assert math.isclose(nums[i], exp[i], rel_tol=1e-12, abs_tol=1e-12), (line, i)
        assert all(nums[i].is_integer() and 1 <= nums[i] <= 5 for i in (9, 10, 11))
        assert math.isclose(nums[12], (nums[9] + nums[10] + nums[11]) / 3, abs_tol=1e-12)
        assert nums[8] == m['actual_batch_size'] == 1 and row[7] == 'NO'
        assert math.isclose(nums[6], m['full_batch_response_s'] / 1, rel_tol=1e-12) and nums[6] > 0 and nums[16] >= 0
        assert -1.000001 <= nums[13] <= 1.000001 and 0 <= nums[14] <= 1.000001 and -1.000001 <= nums[15] <= 1.000001
        assert m['teacher_reference_label'] == teacher[key]['label']
        if m['model_key'] == 'teacher':
            t = teacher[key]
            tin, tout = usage(t)
            assert row[5] == t['label'] and math.isclose(nums[6], float(t['latency_s']), rel_tol=1e-12)
            assert json.loads(row[3]) == (t['request_messages'] if isinstance(t['request_messages'], list) else json.loads(t['request_messages'].replace("'", '"')))
            assert math.isclose(nums[16], (tin + 5 * tout) / 1e6, rel_tol=1e-12, abs_tol=1e-14)
            assert all(abs(nums[i] - 1) < 1e-5 for i in (13, 14, 15)) and m['teacher_self_comparison']
        else:
            assert math.isclose(nums[16], nums[6] * RATE / 3600, rel_tol=1e-12, abs_tol=1e-14)
            assert not m['teacher_self_comparison']
            msgs = json.loads(row[3])
            assert [x['role'] for x in msgs] == ['system', 'user'] and msgs[1]['content'].endswith(
                '\n\n' + '\n'.join(f'Ticket {i}: {x}' for i, x in enumerate(item['tickets'], 1)))
        groups[m['model_key']].append(key)
        # ``cand`` identity: identical ticket/label pairs must have identical judge scores
    assert set(groups) == {'llama_baseline', 'llama_label80', 'llama_label108', 'teacher'}
    assert all(len(v) == len(set(v)) == 500 and set(v) == set(source) for v in groups.values())
    same = collections.defaultdict(set)
    for row, m in zip(rows, prov):
        same[m['judge_candidate_id']].add(tuple(row[9:12]))
    assert all(len(v) == 1 for v in same.values()), 'identical ticket/label pairs have different judge scores'
    result = {'status': 'passed', 'records': len(rows), 'columns': 17, 'clusters': 100, 'prompt_variants': 5,
              'configurations': {k: len(v) for k, v in groups.items()}, 'unique_judged_pairs': len(same)}
    # optional source-log cross-checks
    gens = {}
    for folder in ('label80', 'label108'):
        g = ROOT / 'source_records' / folder / 'raw_generations.jsonl'
        if g.exists():
            gens[folder] = {(r['role'], r['cluster_id'], r['prompt_id']): r for r in jl(g)}
    checked = 0
    for row, m in zip(rows, prov):
        k = m['model_key']
        if k in RUNS and RUNS[k] in gens:
            g = gens[RUNS[k]][(ROLE[k], m['cluster_id'], m['prompt_id'])]
            assert row[5] == g['label'] and math.isclose(float(row[6]), g['latency_s'], rel_tol=1e-9), (m['csv_row'], k)
            checked += 1
    result['student_rows_checked_against_raw_generations'] = checked
    notes.append('raw_generations.jsonl found for ' + (', '.join(gens) or 'none (add with collect_from_drive.py to check student outputs)'))
    cache = {}
    for folder in ('label80', 'label108'):
        for c in (ROOT / 'source_records' / folder).glob('*_rejudge_cache.jsonl') if (ROOT / 'source_records' / folder).exists() else []:
            for j in jl(c):
                if j.get('parsed'):
                    cache.setdefault(folder, {})[j['candidate_id']] = j['parsed']
    judged = 0
    for row, m in zip(rows, prov):
        k = m['model_key']
        folder = 'label108' if k in ('teacher', 'llama_baseline', 'llama_label108') else 'label80'
        if folder in cache and m['judge_candidate_id'] in cache[folder]:
            p = cache[folder][m['judge_candidate_id']]
            assert [int(row[9]), int(row[10]), int(row[11])] == [p['faithfulness'], p['relevance'], p['specificity']], (m['csv_row'], k)
            judged += 1
    result['rows_checked_against_judge_cache'] = judged
    notes.append('judge cache found for ' + (', '.join(cache) or 'none (add with collect_from_drive.py to check scores)'))
    result['notes'] = notes
    result['csv_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
    (ROOT / 'CSV_VALIDATION.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
