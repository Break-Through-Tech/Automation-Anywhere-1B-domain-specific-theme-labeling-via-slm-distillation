# Llama raw CSV data dictionary

One measured output per record, exactly 17 columns . 2,000 rows: baseline, Label-80, Label-108 and teacher, 500 each.

| Column | Type / definition |
|---|---|
| Name of Model | Model identifier and role: baseline, fine-tuned Label-80, fine-tuned Label-108, or claude-haiku-4-5 (teacher). Student names end with "Colab T4, batch size 1". |
| Model Owner | Experiment owner: vd35. This is the researcher responsible for the measurement, not the model vendor. |
| Prompt ID | P1 to P5. |
| Actual Prompt | JSON of the system and user messages for that inference. Student rows carry the project's system message (the shared system text with one added opening sentence, "You are analysing IT support tickets."). Teacher rows carry the messages Haiku actually received (saved teacher log), without that sentence. |
| Input to the Model | JSON array of all ten ticket texts in the cluster, in the frozen order. |
| Output of the Model | The generated label after decoding, with stop tokens removed. |
| Latency | Seconds per label. Students: wall time for one generate call (tokenize, transfer, generate, decode), batch size 1, GPU synchronized. Teacher: successful API request time including network, from the saved log. |
| Batch | Always NO (every row is batch size 1). |
| Batch Size | Always 1. |
| Faithfulness / Relevance / Specificity | Reference-free Claude Haiku 4.5 judge, integers 1-5, temperature 0. |
| Composite | Arithmetic mean of the three judge scores. |
| Cosine Score | Cosine between normalized all-mpnet-base-v2 embeddings of the label and the same-cluster, same-prompt teacher label. |
| ROUGE | ROUGE-L F1, stemming on, against that teacher label. |
| BertScore | BERTScore F1, RoBERTa-large layer 17, IDF off, baseline rescaling off, against that teacher label. |
| Estimated/Approx Cost | USD for this output. Students: Latency x 0.526 / 3600 (historical full-utilization VM+T4 rate, kept for comparability). Teacher: logged input tokens x $1 + output tokens x $5, per million. |

Identical ticket-list/label pairs share a judge score (1,478 unique pairs across 2,000 rows). The judge is an automated rating, not a human annotation. Haiku is both teacher and judge.
Teacher similarity metrics compare each teacher label with itself (about 1.0); they are identity checks, not evidence of teacher quality.
Cost excludes training, model loading, idle hosting, storage, networking and failed requests. `row_provenance.json` maps each CSV line to cluster ID, model key,
judge candidate ID and the teacher reference label.
