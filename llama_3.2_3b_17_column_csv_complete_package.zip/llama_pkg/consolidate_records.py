"""Turn the combined 17-column CSV into the saved records the exporter and validator use.

Writes raw_records_matrix.json (header + typed rows) and row_provenance.json
(per-row cluster id, model key, batch info, judge candidate id, teacher reference label).
Never calls a model or API.   python3 consolidate_records.py combined.csv --out-dir .
"""
import argparse, csv, hashlib, json
from pathlib import Path

csv.field_size_limit(10 ** 9)
HEADERS = ['Name of Model', 'Model Owner', 'Prompt ID', 'Actual Prompt', 'Input to the Model', 'Output of the Model',
           'Latency', 'Batch', 'Batch Size', 'Faithfulness', 'Relevance', 'Specificity', 'Composite', 'Cosine Score',
           'ROUGE', 'BertScore', 'Estimated/Approx Cost']


def cand_id(tickets, label):               # same definition as scripts/rejudge_reffree.py
    return hashlib.sha256(json.dumps([tickets, label], ensure_ascii=False).encode()).hexdigest()


def model_key(name):
    n = name.lower()
    if n.startswith('claude-haiku'):
        return 'teacher'
    if 'baseline' in n:
        return 'llama_baseline'
    if 'label-80' in n:
        return 'llama_label80'
    if 'label-108' in n:
        return 'llama_label108'
    raise ValueError(name)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('csv_path')
    ap.add_argument('--out-dir', default='.')
    ap.add_argument('--workload', default=None, help='evaluation_inputs.json (default: next to this script)')
    a = ap.parse_args()
    root = Path(__file__).resolve().parent
    wl = json.load(open(a.workload or root / 'evaluation_inputs.json', encoding='utf-8'))
    by = {(json.dumps(r['tickets'], ensure_ascii=False), r['prompt_id']): (r['cluster_id'], r['tickets']) for r in wl}
    rows = list(csv.reader(open(a.csv_path, encoding='utf-8', newline='')))
    assert rows[0] == HEADERS, 'header is not the exact 17 columns'
    matrix, prov, teacher_label = [HEADERS], [], {}
    typed = []
    for line, r in enumerate(rows[1:], 2):
        cid, tickets = by[(r[4], r[2])]
        t = list(r)
        for i in (6, 12, 13, 14, 15, 16):
            t[i] = float(r[i])
        for i in (8, 9, 10, 11):
            t[i] = int(float(r[i]))
        typed.append((line, cid, tickets, t))
        if model_key(r[0]) == 'teacher':
            teacher_label[(cid, r[2])] = r[5]
    for line, cid, tickets, t in typed:
        key = model_key(t[0])
        matrix.append(t)
        prov.append({'csv_row': line, 'cluster_id': cid, 'prompt_id': t[2], 'model_key': key,
                     'nominal_batch_size': 1, 'actual_batch_size': t[8], 'full_batch_response_s': t[6], 'batch_index': None,
                     'judge_candidate_id': cand_id(tickets, t[5]),
                     'teacher_reference_label': teacher_label[(cid, t[2])], 'teacher_self_comparison': key == 'teacher'})
    out = Path(a.out_dir)
    json.dump(matrix, open(out / 'raw_records_matrix.json', 'w', encoding='utf-8'), ensure_ascii=False)
    json.dump(prov, open(out / 'row_provenance.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'wrote raw_records_matrix.json ({len(matrix) - 1} rows) and row_provenance.json in {out}')


if __name__ == '__main__':
    main()
