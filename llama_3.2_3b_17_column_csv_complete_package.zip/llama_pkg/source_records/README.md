Filled by collect_from_drive.py: per-run raw_generations.jsonl, judge caches, overlap reports, training data and adapter hashes (label80/, label108/).
