"""Write RESULTS_SUMMARY.md (per-configuration means) from the saved matrix. No API or model calls."""
import json, statistics as st
from pathlib import Path

root = Path(__file__).resolve().parent
m = json.loads((root / 'raw_records_matrix.json').read_text(encoding='utf-8'))
h, rows = m[0], m[1:]
order = ['baseline', 'Label-80', 'Label-108', 'claude-haiku']
def key(n):
    return 'claude-haiku' if n.startswith('claude-haiku') else 'baseline' if 'baseline' in n else 'Label-80' if 'Label-80' in n else 'Label-108'
by = {k: [r for r in rows if key(r[0]) == k] for k in order}
col = {c: i for i, c in enumerate(h)}
lines = ['# Llama 3.2-3B 17-column results (means over 500 rows each)', '',
         '| Configuration | n | Faithfulness | Relevance | Specificity | Composite | Cosine | ROUGE-L | BERTScore | s/label | $/1k labels |',
         '|---|---|---|---|---|---|---|---|---|---|---|']
for k in order:
    v = by[k]
    f = lambda c: st.mean(r[col[c]] for r in v)
    lines.append(f"| {k} | {len(v)} | {f('Faithfulness'):.3f} | {f('Relevance'):.3f} | {f('Specificity'):.3f} | {f('Composite'):.3f} | "
                 f"{f('Cosine Score'):.3f} | {f('ROUGE'):.3f} | {f('BertScore'):.3f} | {f('Latency'):.3f} | {1000 * f('Estimated/Approx Cost'):.3f} |")
lines += ['', 'Judge is Claude Haiku 4.5 (reference-free). Latency is seconds per label at batch size 1. See KNOWN_LIMITATIONS.md.']
(root / 'RESULTS_SUMMARY.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print('\n'.join(lines))
