# Llama 3.2-3B: 17-column results package

Everything needed to rebuild the 2,000-row results table for Llama 3.2-3B-Instruct: the untuned model, two LoRA adapters (Label-80 and Label-108) and the
Claude Haiku 4.5 teacher, each on the same 500 inputs (100 clusters x 5 prompts). Read KNOWN_LIMITATIONS.md before quoting the numbers.

## Rebuild the CSV (about 1 minute, Python 3, no installs)

```bash
python3 export_csv_portable.py raw_records_matrix.json llama_3.2_3b_17_columns_2000rows.csv --expected-rows 2000
python3 validate_llama_csv.py
python3 write_summary.py
```

- The exporter needs a new output filename. Expected SHA256 of the CSV: `bc879db1c7117e75e4e0dd85d6a6675103621cd8523904c5187011f06cfb9a45`.
- The validator checks every row against the frozen inputs and the teacher log, and writes CSV_VALIDATION.json. Expect: 2,000 rows, 17 columns, 4 configurations x 500.
- write_summary.py writes RESULTS_SUMMARY.md. Composite scores: untuned 3.991, Label-80 4.337, Label-108 4.536, teacher 4.575.

## What the two adapters are

| | Label-80 | Label-108 |
|---|---|---|
| Training clusters | about 80 | 108 |
| Training labels | teacher labels as generated | 37 of 560 swapped for a better judge-scored candidate |
| Clusters sharing tickets with the test inputs | 2 | none |
| Recipe | LoRA r=16, alpha=16, dropout 0.05, lr 2e-4, 3 epochs | same |

## How the results were made

1. **Inputs:** 500 frozen inputs (`evaluation_inputs.json`): 100 clusters, ten tickets each, five prompts.
2. **Teacher:** 500 saved Haiku 4.5 labels (`teacher_requests.jsonl`), reused.
3. **Students:** `scripts/run_workload.py` generated one label at a time (greedy, up to 60 new tokens) for the untuned model and each adapter.
4. **Judge:** `scripts/rejudge_reffree.py` scored every unique ticket/label pair once with Haiku 4.5 (no reference answer): Faithfulness, Relevance, Specificity, 1 to 5.
5. **Similarity:** cosine, ROUGE-L and BERTScore against the teacher label for the same cluster and prompt.
6. **Combine:** `combine_runs.py` then `consolidate_records.py` write the saved records used above.

## Run it again in Colab (T4)

Open `08_llama_label108_train_eval.ipynb`. It builds the training data, trains, verifies, generates, judges and exports. You need your project code folder,
your Drive project folder and an Anthropic key (typed with getpass, never saved). Judging costs about $1.30 per run; training about 10 minutes; generation about 23 minutes.
The base model is the ungated `unsloth/Llama-3.2-3B-Instruct`. The notebook paths were edited for this package and not re-run unchanged.

Run `python3 collect_from_drive.py --root <Drive project folder> --pkg <this folder>` to add the large files that are not in the ZIP (raw generations, judge caches with reasons,
training data, adapter hashes). The validator then also checks every student label and judge score against them.

## Files

- **Rebuild:** `export_csv_portable.py`, `validate_llama_csv.py`, `write_summary.py`, `raw_records_matrix.json`, `row_provenance.json`
- **Re-run:** `08_llama_label108_train_eval.ipynb`, `scripts/`, `combine_runs.py`, `consolidate_records.py`, `collect_from_drive.py`
- **Frozen inputs:** `evaluation_inputs.json`, `serving_config.yaml`, `judge_system_prompt.txt`, `metric_settings.json`, `teacher_requests.jsonl`, `selected_*.json`, `clustering_audit.json`
- **Notes:** `DATA_DICTIONARY.md`, `EVALUATION_PROTOCOL.md`, `KNOWN_LIMITATIONS.md`, `configuration_summary.json`, `SHA256.json`
