"""Run in Colab (or anywhere the Drive is mounted) to add the large source records that are NOT in the ZIP:
raw generations, judge caches (with Haiku's written reasons), overlap reports, training data, run configs and adapter hashes.
Then validate_llama_csv.py also checks every student output and judge score against them.

   python3 collect_from_drive.py --root /content/drive/MyDrive/slm-distillation --pkg /content/llama_pkg
Never prints or stores API keys. Missing files are listed, not fatal.
"""
import argparse, glob, hashlib, json, os, shutil
from pathlib import Path

RUNS = {  # package folder -> (eval folder, training data folder, run folder glob)
    'label80': ('consolidated/workload_confirm_v2', 'data/processed_raw_domain',
                'runs/llama_3.2_3b_confirm_domain/confirm_baseline_v2/outputs/20260928_2119_Llama-3.2-3B-Instruct_ep3'),
    'label108': ('consolidated/workload_all112_v2', 'data/processed_all112_v2',
                 'runs/llama_3.2_3b_all112/all112_v2/outputs/*_ep3'),
}
EVAL_FILES = ['raw_generations.jsonl', 'generation_meta.json', 'overlap_report.json', 'workload_17col_rejudge_cache.jsonl',
              'workload_row_map.csv', 'ancheng_format_full500.csv', 'ancheng_format_nooverlap.csv']
DATA_FILES = ['bitext_labeled.csv', 'train.jsonl', 'val.jsonl', 'test.jsonl', 'cluster_splits.json']
EXTRA = {'label108': ['data/processed_all116_v2/training_pairs_scored.csv', 'data/processed_all116_v2/build_report.json',
                      'runs/llama_3.2_3b_all112/all112_v2/config_all112_v2.yaml']}


def sha(p, n=1 << 20):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        while chunk := f.read(n):
            h.update(chunk)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True)
    ap.add_argument('--pkg', required=True)
    a = ap.parse_args()
    root, pkg = Path(a.root), Path(a.pkg)
    missing, adapters = [], {}
    for name, (ev, data, run) in RUNS.items():
        dst = pkg / 'source_records' / name
        dst.mkdir(parents=True, exist_ok=True)
        for f in EVAL_FILES:
            src = root / ev / f
            if src.exists():
                shutil.copy(src, dst / (f if f != 'workload_17col_rejudge_cache.jsonl' else f))
            else:
                missing.append(str(src))
        for f in DATA_FILES:
            src = root / data / f
            if src.exists():
                (dst / 'training_data').mkdir(exist_ok=True)
                shutil.copy(src, dst / 'training_data' / f)
            else:
                missing.append(str(src))
        for rel in EXTRA.get(name, []):
            src = root / rel
            if src.exists():
                (dst / 'training_data').mkdir(exist_ok=True)
                shutil.copy(src, dst / 'training_data' / src.name)
            else:
                missing.append(str(src))
        runs = sorted(glob.glob(str(root / run)), key=os.path.getmtime)
        if runs:
            ad = Path(runs[-1]) / 'models' / 'lora_adapter'
            info = {'run_dir': runs[-1], 'files': {}}
            for f in ('adapter_model.safetensors', 'adapter_config.json'):
                if (ad / f).exists():
                    info['files'][f] = sha(ad / f)
                    if f == 'adapter_config.json':
                        shutil.copy(ad / f, dst / 'adapter_config.json')
            adapters[name] = info
        else:
            missing.append(str(root / run))
    json.dump(adapters, open(pkg / 'source_records' / 'ADAPTER_HASHES.json', 'w'), indent=1)
    hashes = {str(p.relative_to(pkg)): sha(p) for p in sorted(pkg.rglob('*')) if p.is_file() and p.name != 'SHA256.json'}
    json.dump(hashes, open(pkg / 'SHA256.json', 'w'), indent=1)
    print(f'copied source records into {pkg}/source_records; hashed {len(hashes)} files into SHA256.json')
    print('adapter hashes:', json.dumps(adapters, indent=1)[:600])
    print('MISSING (not fatal):' if missing else 'nothing missing', *missing, sep='\n  ')


if __name__ == '__main__':
    main()
