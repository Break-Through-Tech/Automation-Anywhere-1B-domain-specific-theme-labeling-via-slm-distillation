"""Combine the per-run 17-column CSVs into one 2,000-row table (baseline, Label-80, Label-108, teacher).

Inputs are the ancheng_format_full500.csv files that run_workload.py --stage finalize writes for each run.
  --label80-csv   run of the first adapter  (only its fine-tuned rows are used)
  --label108-csv  run of the second adapter (its baseline, fine-tuned and teacher rows are used)
Teacher rows get their real request messages from the saved teacher log (older exports left them as "[]").
Never calls a model or API.
"""
import argparse, ast, csv, json, sys
from pathlib import Path

csv.field_size_limit(10 ** 9)
NAMES = {
    'baseline': 'Llama-3.2-3B-Instruct (baseline, Colab T4, batch size 1)',
    'label80': 'Llama-3.2-3B-Instruct (fine-tuned Label-80: ~80 clusters, teacher labels, Colab T4, batch size 1)',
    'label108': 'Llama-3.2-3B-Instruct (fine-tuned Label-108: 108 clusters, judge-filtered labels, Colab T4, batch size 1)',
    'teacher': 'claude-haiku-4-5 (teacher)',
}


def read(path):
    with open(path, encoding='utf-8', newline='') as f:
        r = csv.DictReader(f)
        return r.fieldnames, list(r)


def role(name):
    n = name.lower()
    if n.startswith('claude-haiku'):
        return 'teacher'
    return 'baseline' if 'baseline' in n else 'finetuned' if 'fine-tuned' in n else None


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--label80-csv', required=True)
    ap.add_argument('--label108-csv', required=True)
    ap.add_argument('--teacher-requests', required=True, help='teacher_requests.jsonl (saved Haiku log)')
    ap.add_argument('--owner', default='vd35')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    if Path(a.out).exists():
        sys.exit(f'refusing to replace {a.out}')
    h80, r80 = read(a.label80_csv)
    h108, r108 = read(a.label108_csv)
    assert h80 == h108 and len(h80) == 17, 'both inputs must be the exact 17-column format'
    tlog = {}
    for line in open(a.teacher_requests, encoding='utf-8'):
        if line.strip():
            t = json.loads(line)
            tlog[(t['cluster_id'], t['prompt_id'])] = t
    ei = {(r['cluster_id'], r['prompt_id']): r['tickets'] for r in json.load(open(Path(a.teacher_requests).with_name('evaluation_inputs.json'), encoding='utf-8'))}
    by_tickets = {(json.dumps(t, ensure_ascii=False), k[1]): k for k, t in ei.items()}
    out = []
    for r in r108:
        if role(r['Name of Model']) == 'baseline':
            out.append(('baseline', r))
    for r in r80:
        if role(r['Name of Model']) == 'finetuned':
            out.append(('label80', r))
    for r in r108:
        if role(r['Name of Model']) == 'finetuned':
            out.append(('label108', r))
    for r in r108:
        if role(r['Name of Model']) == 'teacher':
            k = by_tickets[(r['Input to the Model'], r['Prompt ID'])]
            msgs = tlog[k]['request_messages']
            if isinstance(msgs, str):
                msgs = ast.literal_eval(msgs)
            r = dict(r)
            r['Actual Prompt'] = json.dumps(msgs, ensure_ascii=False)
            out.append(('teacher', r))
    counts = {k: sum(1 for x, _ in out if x == k) for k in NAMES}
    assert all(v == 500 for v in counts.values()), counts
    with open(a.out, 'x', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=h108, lineterminator='\r\n')
        w.writeheader()
        for key, r in out:
            r = dict(r)
            r['Name of Model'] = NAMES[key]
            r['Model Owner'] = a.owner
            w.writerow(r)
    print(f'wrote {a.out}: {len(out)} rows {counts}')


if __name__ == '__main__':
    main()
